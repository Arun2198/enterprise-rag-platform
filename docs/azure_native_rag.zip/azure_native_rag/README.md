# Azure-Native RAG — Reachable POC

An all-Azure-native Retrieval-Augmented Generation system, built up through
a design conversation that covered: multi-format ingestion (PDF, DOCX,
XLSX, CSV, HTML, DWG), mixed content (typed text, tables, handwritten
scans, diagrams, photos with readings), RBAC/ACL access control, and
public reachability (API auth, secrets management, logging).

This is the **Azure-native** version — Azure AI Search replaces the
ChromaDB-based local-first version's vector store (a deliberate,
cost-aware choice made explicitly in the design conversation: "I know
with AI Search we will incur cost"), and every other component that can
be Azure-native, is.

---

## 1. Tech stack

| Layer | Component | Why |
|---|---|---|
| Raw storage | **Azure Blob Storage** | Source of truth for uploaded documents |
| Text/table parsing | **Azure AI Document Intelligence** (Layout model) | Preserves table structure and page headings; also reads handwriting (with caveats — see §6) |
| Structured data | **pandas / openpyxl** (no AI service) | XLSX/CSV are already perfectly structured — no reason to pay to re-derive that |
| Visual content | **Azure OpenAI vision** (gpt-4o-mini bulk, gpt-4o high-fidelity) | Diagrams, drawings, and photos need genuine image understanding, not OCR |
| DWG conversion | **ODA File Converter** (external tool) | No Azure service reads DWG directly — this converts DWG → PDF first |
| Chunking | **LangChain `RecursiveCharacterTextSplitter`** | Paragraph/sentence-boundary-aware splitting |
| Embeddings | **Azure OpenAI `text-embedding-3-small`** | Cheapest embedding tier with strong quality for search |
| Vector store | **Azure AI Search** | Native RBAC list-field filtering + built-in semantic reranking |
| Generation | **Azure OpenAI** (`gpt-4o-mini` fast tier, `gpt-4o` accurate tier) | Same resource as embeddings/vision, different deployments |
| App hosting | **Azure Container Apps** | Public HTTPS endpoint, scales to zero, one hosting model for API + (optionally) DWG conversion |
| Secrets | **Azure Container Apps built-in secrets store** (Key Vault optional) | Works under plain Contributor access — no Key Vault access-policy permissions needed. See §9. |
| Service auth | **Connection strings / API keys**, passed as Container Apps secrets | Managed Identity + Key Vault is a documented upgrade path (§9), not required to get running |
| Endpoint protection | **Shared API key** (not API Management) | Sufficient at this scale — see the earlier cost discussion |
| Logging/monitoring | **Application Insights** | Queryable from the Portal without container shell access |
| CI | **GitHub Actions** (`pytest` on every push) | Scoped down deliberately — no auto-deploy yet |

---

## 2. Project structure

```
azure_native_rag/
├── README.md
├── requirements.txt
├── .env.example
├── config.py                          <- central config; pulls from Key Vault if KEY_VAULT_URL is set, else .env
├── pytest.ini
├── Dockerfile
├── .dockerignore
├── .gitignore
├── data/
│   ├── raw_docs/                       <- put files here, or sync from Blob Storage
│   ├── processed/                       <- chunks.jsonl, ingestion_manifest.json, extracted_images/, dwg_converted/
│   ├── eval/test_questions.jsonl        <- evaluation harness test set
│   └── metadata_manifest.json           <- per-file document_type / data_source / RBAC roles
├── logs/                                <- app.log (local fallback when Application Insights isn't configured)
├── reports/                              <- evaluation_report.json
├── infra/
│   ├── azure_setup.sh                    <- az CLI script: creates every Azure resource (scoped for an existing, client-managed resource group — no Key Vault, no RBAC role assignment; see §9)
│   └── create_search_index.py             <- one-time script: creates the Azure AI Search index schema
├── .github/workflows/ci.yml               <- pytest on every push
├── src/
│   ├── __init__.py
│   ├── logging_setup.py                    <- console + file + Application Insights
│   ├── auth.py                              <- API key check for the public endpoint
│   ├── blob_storage.py                       <- upload/download to Blob Storage
│   ├── document_intelligence_loader.py        <- PDF/DOCX/HTML text+table extraction (Track 1)
│   ├── structured_loader.py                    <- XLSX/CSV direct parsing (Track 2)
│   ├── image_extractor.py                       <- pulls embedded images out of PDFs (Track 3, part 1)
│   ├── vision_captioner.py                       <- captions images via Azure OpenAI vision (Track 3, part 2)
│   ├── dwg_converter.py                           <- DWG -> PDF via ODA File Converter
│   ├── document_loader.py                          <- orchestrates all 3 tracks + incremental ingestion
│   ├── incremental_ingestion.py                     <- content-hash manifest, skips unchanged files
│   ├── chunker.py                                    <- recursive splitting, carries provenance
│   ├── embedder.py                                    <- Azure OpenAI embeddings, batched + retried
│   ├── vector_store.py                                 <- Azure AI Search (add/query, RBAC, semantic ranking)
│   ├── metadata_filter.py                               <- OData filter construction (RBAC/type/source)
│   ├── query_processor.py                                <- history-aware query rewriting
│   ├── context_selector.py                                <- dedup + token budgeting
│   ├── prompt_builder.py                                   <- citation-aware prompt construction
│   ├── llm_router.py                                        <- fast/accurate Azure OpenAI deployment routing
│   ├── llm_client.py                                         <- low-level Azure OpenAI chat calls
│   ├── guardrails.py                                          <- input/output safety checks
│   ├── evaluation.py                                           <- retrieval metrics + LLM-as-judge
│   └── rag_pipeline.py                                          <- orchestrates ingestion + query end to end
├── scripts/
│   ├── test_connections.py               <- run FIRST: verifies every Azure resource is reachable
│   ├── ingest.py                          <- CLI: build the index
│   ├── query.py                            <- CLI: ask a question (single-shot or --interactive)
│   ├── evaluate.py                          <- CLI: run the evaluation harness
│   └── convert_dwg.py                        <- CLI: test DWG conversion on one file
├── app.py                                <- FastAPI app (the public, reachable API)
└── tests/                                <- pytest suite (24 tests, mocked Azure SDKs)
```

---

## 3. How to implement — step by step

### Step 0 — Prerequisites

- An Azure subscription with permission to create resources
- Azure CLI installed, logged in (`az login`)
- Python 3.11+
- Docker (for building the deployment image)
- [ODA File Converter](https://www.opendesign.com/guestfiles/oda_file_converter) installed, **only if you have DWG files** — see §7

### Step 1 — Create every Azure resource

```bash
chmod +x infra/azure_setup.sh
./infra/azure_setup.sh
```

**This script assumes you're working inside an existing, client-managed
resource group under Contributor-only access** — it does NOT create a
resource group (edit `RESOURCE_GROUP` at the top of the script if yours
isn't named `rg-projectfusion_dev`), auto-detects the region from that
existing resource group, and does NOT use Key Vault or assign any RBAC
roles (both typically need permissions beyond plain Contributor — see §9
for the reasoning and the upgrade path if you're later given elevated access).

Run this **section by section** rather than all at once — it prints
connection strings/keys/endpoints as it goes, which you'll copy into
`.env`. The script itself pauses and asks you to confirm `.env` is filled
in before continuing to the deployment steps, so you can't accidentally
race ahead of it.

If your client's environment enforces mandatory resource tags or naming
conventions (common in managed environments), you may need to add e.g.
`--tags project=fusion env=dev` to the `az ... create` commands — Azure
Policy will name exactly which policy blocked you if this applies.

### Step 2 — Configure local `.env`

```bash
cp .env.example .env
```

Fill in every value printed by Step 1. Leave `KEY_VAULT_URL` blank for
now — that gets set once you're ready to deploy (Step 9).

### Step 3 — Install dependencies

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Step 4 — Create the Azure AI Search index

```bash
python -m infra.create_search_index
```

One-time step — creates the index schema (vector field, RBAC list field,
semantic configuration) that `src/vector_store.py` reads and writes
against. Re-run only if you intentionally change the schema (this
recreates the index, deleting existing data).

### Step 5 — Verify everything is reachable

```bash
python -m scripts.test_connections
```

Checks Blob Storage, Document Intelligence, Azure OpenAI (embeddings +
chat), Azure AI Search, Key Vault (skipped if not configured yet), and
whether ODA File Converter is installed (skipped with a note if not — DWG
files just won't be processed until it is).

### Step 6 — Add your documents

Either upload directly to the Blob container, or drop files into
`data/raw_docs/` and sync up:

```bash
python -m scripts.ingest --download-only   # pulls from Blob into data/raw_docs
# — or, if you added files locally first —
python -c "from src.blob_storage import upload_directory; upload_directory('data/raw_docs')"
```

Then edit `data/metadata_manifest.json` to tag any files that need
non-default `document_type`, `data_source`, or `allowed_roles`.

### Step 7 — DWG conversion setup (skip if you have no DWG files)

Install [ODA File Converter](https://www.opendesign.com/guestfiles/oda_file_converter)
on the machine/container that runs ingestion. Test it on one file:

```bash
python -m scripts.convert_dwg path/to/one_drawing.dwg
```

If this succeeds, ingestion will convert DWG files automatically. If ODA
File Converter isn't installed, ingestion still runs fine — DWG files are
just skipped with a logged warning, and everything else ingests normally.

### Step 8 — Run ingestion

```bash
python -m scripts.ingest --skip-download
```

This is the step that actually costs money (Document Intelligence pages,
vision captioning, embeddings) — see §6 for cost-control notes before
running it over your full 500MB corpus for the first time. Incremental
ingestion (on by default) means subsequent runs only process new/changed
files.

Check `data/processed/chunks.jsonl` afterward to sanity-check what was
actually extracted and chunked.

### Step 9 — Deploy: secrets, without needing Key Vault permissions

Steps 1-8 work entirely with `.env`. Step 1's script already deployed the
Container App with every secret (storage connection string, API keys,
your generated `API_KEY`) stored in **Azure Container Apps' own built-in
secrets store** — encrypted at rest, not visible in plaintext in the app's
configuration, and referenced in the app via `secretref:` rather than
appearing as raw values. This needs nothing beyond the Contributor access
you already have on the resource group.

This is **not** Key Vault, and deliberately so: creating a Key Vault and
setting access policies on it both typically require permissions beyond
plain Contributor (closer to Owner or User Access Administrator) — see
§6 "Known limitations" for what you'd gain by upgrading to it later, if
you're given elevated access.

To update the deployed app after a code change:
```bash
az acr build --registry <your-acr-name> --image rag-poc-api:latest .
az containerapp update --name rag-poc-api --resource-group rg-projectfusion_dev \
  --image <your-acr-name>.azurecr.io/rag-poc-api:latest
```

### Step 10 — Verify the deployed API

```bash
curl https://<your-container-app-url>/health

curl -X POST https://<your-container-app-url>/query \
  -H "Content-Type: application/json" \
  -H "X-API-Key: <the key infra/azure_setup.sh generated>" \
  -d '{"question": "What does the inspection report say about corrosion?", "roles": ["employee"]}'
```

### Step 11 (optional) — Evaluate retrieval + answer quality

```bash
# edit data/eval/test_questions.jsonl with real questions first
python -m scripts.evaluate
```

Writes `reports/evaluation_report.json` — recall/precision@k plus (if
`EVAL_LLM_JUDGE_ENABLED=true`) LLM-judged relevance/faithfulness.

### Step 12 (optional) — Run the test suite

```bash
pytest -v
```

24 tests, all against mocked Azure SDKs — no real Azure resources or
credentials needed. This is also what `.github/workflows/ci.yml` runs on
every push.

---

## 4. What changed from the local-first (ChromaDB) version

| Component | Local-first version | This version |
|---|---|---|
| Vector store | ChromaDB (local, free) | **Azure AI Search** (managed, incurs fixed cost — the one deliberate tradeoff you accepted) |
| Embeddings | Sentence Transformers (local, free) | Azure OpenAI `text-embedding-3-small` |
| Generation | Ollama (local, free) / Azure OpenAI (optional) | Azure OpenAI only |
| PDF/DOCX/HTML parsing | PyMuPDF / python-docx / BeautifulSoup | Azure AI Document Intelligence |
| Reranking | Self-hosted cross-encoder | Azure AI Search's built-in semantic ranker (one fewer component to run) |
| RBAC/ACL storage | Per-role boolean flags (ChromaDB workaround) | Native list field + OData `any()` filter (Azure AI Search supports this directly) |
| Secrets | `.env` only | `.env` locally, **Container Apps built-in secrets store** once deployed (Key Vault optional — see §6) |
| Reachability | Local only | **Azure Container Apps**, API-key protected |
| Logging | Console + local file | Console + local file + **Application Insights** once deployed |
| New: structured data | N/A | XLSX/CSV parsed directly, deliberately bypassing any AI service |
| New: visual content | N/A | Diagrams/drawings/photos captioned via Azure OpenAI vision |
| New: DWG | N/A (not supported) | Converted to PDF externally, then flows through the same visual pipeline |
| New: incremental ingestion | N/A (re-processed everything every run) | Content-hash manifest skips unchanged files — meaningful now that parsing costs money |

---

## 5. Understanding the three ingestion tracks

Every file is routed to one or more of these, per the design discussion
("your PDFs aren't one content type — they're a container holding at
least four"):

- **Track 1 (text/tables)** — `.pdf`, `.docx`, `.html`/`.htm` →
  `document_intelligence_loader.py`. One Section per page, tables
  rendered as markdown and appended to their page's text.
- **Track 2 (structured data)** — `.xlsx`, `.csv` → `structured_loader.py`.
  Direct parsing, no AI service — this data doesn't need "understanding,"
  it's already structured.
- **Track 3 (visual content)** — embedded images inside PDFs above
  `MIN_IMAGE_PIXELS` → `image_extractor.py` (pulls them out) +
  `vision_captioner.py` (describes them). `.dwg` files go through
  `dwg_converter.py` first, then the same Track 1 + Track 3 pipeline as
  any PDF.

A single PDF typically runs through **both** Track 1 and Track 3 — these
are complementary passes over the same file, not alternatives.

---

## 6. Known limitations — stated plainly, not glossed over

- **Handwriting**: Document Intelligence detects handwritten text, but
  reliability varies with legibility. Spot-check a sample of your actual
  handwritten pages before trusting it at scale.
- **Analog gauge readings**: vision models can usually read a *digital*
  display reliably; an *analog needle gauge* is inherently unreliable to
  read precisely with a general-purpose vision model. Treat captioned
  analog readings as estimates — the prompt builder labels these sources
  as "described from an image" specifically so the LLM (and the user)
  knows not to treat them as verbatim.
- **Chart *interpretation* vs. chart *labels***: Document Intelligence
  reads text labels on a chart, not the visual trend. Vision captioning
  handles interpretation, but for genuinely numeric analysis, finding the
  underlying data table (if one exists as XLSX/CSV) will always be more
  reliable than reading a chart image.
- **Excel embedded charts**: `structured_loader.py` reads XLSX *data*, not
  charts embedded as images within the workbook. If your XLSX files have
  meaningful embedded charts, they currently fall through both tracks —
  a gap worth closing later (would need image extraction from XLSX,
  similar to the PDF path) if it turns out to matter.
- **DWG geometric understanding**: the DWG pipeline gets you the drawing's
  *page content* (labels, dimensions, title-block text, a vision
  description of the drawing) — it does not give true geometric/CAD-level
  understanding. For that, Autodesk Platform Services is the correct tool,
  and is intentionally out of scope here (a separate vendor relationship,
  not an Azure service).
- **Cross-service auth is inconsistent by design, for now**: Blob Storage
  uses a connection string (with Managed Identity as documented upgrade
  path); Document Intelligence/Azure OpenAI/Azure AI Search use API keys
  passed as Container Apps secrets. All three SDKs support Managed
  Identity too — unifying on it everywhere is a reasonable next step,
  deliberately not done in this first deployment to keep the initial
  setup simpler to get working.
- **No Key Vault, by permission necessity, not preference**: this
  deployment assumes Contributor-only access on an existing, client-managed
  resource group (`infra/azure_setup.sh` is written for exactly this).
  Creating a Key Vault and setting access policies on it both typically
  need permissions beyond Contributor (Owner or User Access Administrator).
  Secrets are instead stored in Azure Container Apps' own built-in secrets
  store — genuinely encrypted at rest and not visible in plaintext
  configuration, just without Key Vault's extras (rotation without
  redeploying, audit logging, centralized sharing across multiple apps).
  `config.py` already supports switching to Key Vault with zero code
  changes (just set `KEY_VAULT_URL`) if you're later given elevated
  permissions, or a client admin sets up the Key Vault + role assignments
  on your behalf.

---

## 7. Cost-control features already built in

- **Incremental ingestion** (`ENABLE_INCREMENTAL_INGESTION=true`) — skips
  re-processing unchanged files, meaningful now that Document Intelligence
  and vision captioning cost money per use.
- **`MIN_IMAGE_PIXELS`** — filters out logos/icons/dividers before they
  ever reach the vision captioning step.
- **Two-tier vision captioning** — bulk ingestion uses the cheap
  `gpt-4o-mini` deployment; the expensive `gpt-4o` high-fidelity path
  (`vision_captioner.caption_image_high_fidelity()`) exists but is **not**
  wired into every query automatically — call it deliberately when a user
  needs a sharper read of a specific retrieved image.
- **LLM router** — routes simple questions to `gpt-4o-mini`, only escalates
  to `gpt-4o` for long/complex questions.

Before running ingestion over your full 500MB corpus, consider a pilot
batch (20-30 representative files) to get a real sense of per-document
image counts and cost, rather than guessing.

---

## 8. Extension points, deliberately deferred

These came up in the design discussion and were consciously scoped out of
this version — noted here so the reasoning isn't lost:

- **Azure Key Vault + Managed Identity everywhere** — skipped specifically
  because it needs permissions beyond Contributor-on-one-resource-group;
  revisit if you're given elevated access or a client admin sets it up.
  `config.py` already supports this switch with no code changes.
- **Azure API Management** — skipped in favor of a simple API key; revisit
  if this grows beyond a single API or gains external partner consumers.
- **Entra ID / per-user auth** — skipped in favor of one shared API key;
  revisit once you need to enforce `--role` by *who someone is*, not by
  *which key they were handed*.
- **CI/CD auto-deploy** — CI runs tests on every push; deployment stays a
  manual `az acr build` + `az containerapp update` for now.
- **Azure Budget alerts** — not code, a five-minute Portal task; set one
  up before your first large ingestion run, not after.
