# Makes "infra" a Python package so infra scripts can be run as
# "python -m infra.create_search_index"
