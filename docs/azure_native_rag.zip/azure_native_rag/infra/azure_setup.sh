#!/usr/bin/env bash
# =============================================================================
# infra/azure_setup.sh
# =============================================================================
# Creates every Azure resource this project needs, using the Azure CLI.
# Run section by section (copy/paste, don't just blindly execute the whole
# file) so you can watch each resource actually get created and fill in
# .env as you go — that matches the numbered steps in README "How to
# implement", which this script mirrors exactly.
#
# THIS VERSION IS SCOPED FOR WORKING INSIDE AN EXISTING, CLIENT-MANAGED
# RESOURCE GROUP under typical "Contributor on this resource group only"
# access — NOT subscription-level admin access. Concretely, that means:
#   - It does NOT create a resource group (assumes one already exists).
#   - It does NOT use Azure Key Vault (creating one and setting access
#     policies on it both need permissions beyond plain Contributor).
#   - It does NOT assign any RBAC roles (e.g. "Storage Blob Data
#     Contributor" to a Managed Identity) — role assignment needs "User
#     Access Administrator" or "Owner", which Contributor does not include.
#   - Secrets are stored using Azure Container Apps' own built-in secrets
#     store instead of Key Vault — encrypted at rest, not visible in plain
#     text in the app's configuration, and creating/updating them is a
#     normal Contributor-level action on a resource you already manage.
#
# If you're later given elevated permissions (or a client admin sets up
# Key Vault + role assignments themselves), config.py already supports
# switching to Key Vault with zero code changes — just set KEY_VAULT_URL.
# See README "Known limitations" for that upgrade path.
#
# Prerequisites:
#   - Azure CLI installed and you've run `az login`
#   - Contributor access on the target resource group
#
# Exact flag names/output shapes for `az` commands can shift between CLI
# versions — if a command errors, check `az <command> --help` for the
# current syntax on your installed CLI version before assuming the script
# is wrong.
# =============================================================================

set -euo pipefail

# -----------------------------------------------------------------------
# Configuration — edit RESOURCE_GROUP if yours has a different name;
# everything else can usually be left as-is.
# -----------------------------------------------------------------------
RESOURCE_GROUP="rg-projectfusion_dev"   # <- the client's existing resource group

# Auto-detected from the existing resource group, so you don't need to
# guess or manually look this up — every resource below gets created in
# whichever region the resource group itself already lives in.
LOCATION=$(az group show --name "$RESOURCE_GROUP" --query location -o tsv)
echo "Using existing resource group '$RESOURCE_GROUP' in region '$LOCATION'."

STORAGE_ACCOUNT="ragpocstorage$RANDOM" # storage account names must be globally unique, lowercase, no hyphens
CONTAINER_NAME="rag-poc-docs"
DOC_INTEL_NAME="rag-poc-docintel"
OPENAI_NAME="rag-poc-openai"
SEARCH_NAME="rag-poc-search"
APP_INSIGHTS_NAME="rag-poc-insights"
LOG_ANALYTICS_NAME="rag-poc-logs"
CONTAINERAPPS_ENV="rag-poc-env"
CONTAINERAPP_NAME="rag-poc-api"
ACR_NAME="ragpocacr$RANDOM"            # container registry name must be globally unique

# If the client's environment enforces mandatory tags or a specific naming
# convention (ask before running, if unsure), add e.g. `--tags project=fusion
# env=dev` to each `az ... create` command below — Azure Policy will reject
# resource creation otherwise, and the error message will usually name
# exactly which policy blocked it.

echo "=== Step 1: Blob Storage ==="
az storage account create \
  --name "$STORAGE_ACCOUNT" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --sku Standard_LRS

az storage container create \
  --name "$CONTAINER_NAME" \
  --account-name "$STORAGE_ACCOUNT"

STORAGE_CONNECTION_STRING=$(az storage account show-connection-string \
  --name "$STORAGE_ACCOUNT" --resource-group "$RESOURCE_GROUP" \
  --query connectionString -o tsv)
echo "Storage connection string (copy into .env as AZURE_STORAGE_CONNECTION_STRING):"
echo "$STORAGE_CONNECTION_STRING"

echo "=== Step 2: Document Intelligence ==="
az cognitiveservices account create \
  --name "$DOC_INTEL_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --kind FormRecognizer \
  --sku S0 \
  --yes

DOC_INTEL_ENDPOINT=$(az cognitiveservices account show \
  --name "$DOC_INTEL_NAME" --resource-group "$RESOURCE_GROUP" \
  --query properties.endpoint -o tsv)
DOC_INTEL_KEY=$(az cognitiveservices account keys list \
  --name "$DOC_INTEL_NAME" --resource-group "$RESOURCE_GROUP" \
  --query key1 -o tsv)
echo "Document Intelligence endpoint (copy into .env as DOCUMENT_INTELLIGENCE_ENDPOINT): $DOC_INTEL_ENDPOINT"
echo "Document Intelligence key (copy into .env as DOCUMENT_INTELLIGENCE_KEY): $DOC_INTEL_KEY"

echo "=== Step 3a: Azure OpenAI resource ==="
az cognitiveservices account create \
  --name "$OPENAI_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --kind OpenAI \
  --sku S0 \
  --yes

AZURE_OPENAI_ENDPOINT=$(az cognitiveservices account show \
  --name "$OPENAI_NAME" --resource-group "$RESOURCE_GROUP" \
  --query properties.endpoint -o tsv)
AZURE_OPENAI_API_KEY=$(az cognitiveservices account keys list \
  --name "$OPENAI_NAME" --resource-group "$RESOURCE_GROUP" \
  --query key1 -o tsv)
echo "Azure OpenAI endpoint (copy into .env as AZURE_OPENAI_ENDPOINT): $AZURE_OPENAI_ENDPOINT"
echo "Azure OpenAI key (copy into .env as AZURE_OPENAI_API_KEY): $AZURE_OPENAI_API_KEY"

echo "=== Step 3b: Deploy the three models you need ==="
az cognitiveservices account deployment create \
  --name "$OPENAI_NAME" --resource-group "$RESOURCE_GROUP" \
  --deployment-name "text-embedding-3-small" \
  --model-name "text-embedding-3-small" --model-version "1" \
  --model-format OpenAI --sku-capacity 30 --sku-name "Standard"

az cognitiveservices account deployment create \
  --name "$OPENAI_NAME" --resource-group "$RESOURCE_GROUP" \
  --deployment-name "gpt-4o-mini" \
  --model-name "gpt-4o-mini" --model-version "2024-07-18" \
  --model-format OpenAI --sku-capacity 30 --sku-name "Standard"

az cognitiveservices account deployment create \
  --name "$OPENAI_NAME" --resource-group "$RESOURCE_GROUP" \
  --deployment-name "gpt-4o" \
  --model-name "gpt-4o" --model-version "2024-08-06" \
  --model-format OpenAI --sku-capacity 10 --sku-name "Standard"

echo "=== Step 3c: Azure AI Search ==="
# "basic" is the cheapest tier with semantic ranking support — "free" tier
# exists but doesn't support semantic ranking, which this project relies on.
az search service create \
  --name "$SEARCH_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --sku basic

AZURE_SEARCH_ENDPOINT="https://${SEARCH_NAME}.search.windows.net"
AZURE_SEARCH_API_KEY=$(az search admin-key show \
  --service-name "$SEARCH_NAME" --resource-group "$RESOURCE_GROUP" \
  --query primaryKey -o tsv)
echo "Azure AI Search endpoint (copy into .env as AZURE_SEARCH_ENDPOINT): $AZURE_SEARCH_ENDPOINT"
echo "Azure AI Search admin key (copy into .env as AZURE_SEARCH_API_KEY): $AZURE_SEARCH_API_KEY"

echo "=== Step 4: Log Analytics + Application Insights (for logging once deployed) ==="
az monitor log-analytics workspace create \
  --resource-group "$RESOURCE_GROUP" \
  --workspace-name "$LOG_ANALYTICS_NAME"

WORKSPACE_ID=$(az monitor log-analytics workspace show \
  --resource-group "$RESOURCE_GROUP" --workspace-name "$LOG_ANALYTICS_NAME" \
  --query id -o tsv)

az monitor app-insights component create \
  --app "$APP_INSIGHTS_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --workspace "$WORKSPACE_ID"

APP_INSIGHTS_CONNECTION_STRING=$(az monitor app-insights component show \
  --app "$APP_INSIGHTS_NAME" --resource-group "$RESOURCE_GROUP" \
  --query connectionString -o tsv)
echo "Application Insights connection string (copy into .env as APPLICATIONINSIGHTS_CONNECTION_STRING): $APP_INSIGHTS_CONNECTION_STRING"

echo "=== Step 5: fill in your local .env now, using every value printed above ==="
echo "Copy .env.example to .env if you haven't already, then paste in each value before continuing."
read -p "Press Enter once .env is filled in, to continue ..."

echo "=== Step 6: Container Registry (to host your built Docker image) ==="
az acr create \
  --name "$ACR_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --sku Basic \
  --admin-enabled true

echo "Building and pushing the image ..."
az acr build --registry "$ACR_NAME" --image rag-poc-api:latest .

echo "=== Step 7: Container Apps environment + app ==="
az containerapp env create \
  --name "$CONTAINERAPPS_ENV" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --logs-workspace-id "$WORKSPACE_ID"

ACR_LOGIN_SERVER=$(az acr show --name "$ACR_NAME" --query loginServer -o tsv)

# Generate the API key that will protect your public endpoint.
GENERATED_API_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
echo "Generated API key (save this somewhere safe — you'll need it to call your deployed API): $GENERATED_API_KEY"

# Every sensitive value is passed via --secrets, which stores it in Azure
# Container Apps' own encrypted secrets store (NOT Key Vault, but not
# plaintext either) — this is what makes Key Vault avoidable here.
# --env-vars then references each one with "secretref:<name>" instead of
# embedding the actual value, so nothing sensitive appears in the app's
# visible configuration or in `az containerapp show` output.
az containerapp create \
  --name "$CONTAINERAPP_NAME" \
  --resource-group "$RESOURCE_GROUP" \
  --environment "$CONTAINERAPPS_ENV" \
  --image "${ACR_LOGIN_SERVER}/rag-poc-api:latest" \
  --registry-server "$ACR_LOGIN_SERVER" \
  --target-port 8000 \
  --ingress external \
  --min-replicas 0 \
  --max-replicas 3 \
  --secrets \
    "storage-connection-string=$STORAGE_CONNECTION_STRING" \
    "document-intelligence-key=$DOC_INTEL_KEY" \
    "azure-openai-api-key=$AZURE_OPENAI_API_KEY" \
    "azure-search-api-key=$AZURE_SEARCH_API_KEY" \
    "applicationinsights-connection-string=$APP_INSIGHTS_CONNECTION_STRING" \
    "api-key=$GENERATED_API_KEY" \
  --env-vars \
    "AZURE_STORAGE_CONNECTION_STRING=secretref:storage-connection-string" \
    "DOCUMENT_INTELLIGENCE_KEY=secretref:document-intelligence-key" \
    "AZURE_OPENAI_API_KEY=secretref:azure-openai-api-key" \
    "AZURE_SEARCH_API_KEY=secretref:azure-search-api-key" \
    "APPLICATIONINSIGHTS_CONNECTION_STRING=secretref:applicationinsights-connection-string" \
    "API_KEY=secretref:api-key" \
    "AZURE_STORAGE_CONTAINER=${CONTAINER_NAME}" \
    "DOCUMENT_INTELLIGENCE_ENDPOINT=${DOC_INTEL_ENDPOINT}" \
    "AZURE_OPENAI_ENDPOINT=${AZURE_OPENAI_ENDPOINT}" \
    "AZURE_SEARCH_ENDPOINT=${AZURE_SEARCH_ENDPOINT}" \
    "AZURE_SEARCH_INDEX_NAME=rag-poc-index"

# Note: no --system-assigned identity, no role assignments, no Key Vault
# policy grants — none are needed with this secrets approach. If you're
# later given elevated permissions and want to move to Key Vault +
# Managed Identity, see README "Known limitations" for that upgrade path;
# config.py already supports it without any code changes.

echo ""
echo "=== Setup complete ==="
echo "Container App URL:"
az containerapp show --name "$CONTAINERAPP_NAME" --resource-group "$RESOURCE_GROUP" --query properties.configuration.ingress.fqdn -o tsv
echo ""
echo "Next: run 'python -m infra.create_search_index' (locally, with .env filled in) to create the search index,"
echo "then 'python -m scripts.test_connections' to verify everything, then 'python -m scripts.ingest'."
