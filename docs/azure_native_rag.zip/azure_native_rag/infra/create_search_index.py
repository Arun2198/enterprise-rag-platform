"""
infra/create_search_index.py
------------------------------
Run this ONCE, after creating your Azure AI Search resource (README Step
4), to create the index that vector_store.py reads and writes against.
Safe to re-run — it recreates the index if one with the same name already
exists (this DELETES any previously indexed data, so only re-run
intentionally, e.g. if you change the schema and need to re-ingest anyway).

Usage:
    python -m infra.create_search_index

This defines:
  - The field schema (id, content, content_vector, plus every metadata
    field vector_store.py writes/reads).
  - A vector search configuration (HNSW algorithm — the standard choice
    for approximate nearest-neighbor vector search at this scale).
  - A semantic configuration named "default-semantic-config" — this exact
    name is what vector_store.py's query() references when
    ENABLE_SEMANTIC_RANKING=true, so if you rename it here, update
    vector_store.py to match.
"""

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    SimpleField,
    SearchableField,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
    SemanticConfiguration,
    SemanticPrioritizedFields,
    SemanticField,
    SemanticSearch,
)

import config


def build_index_definition() -> SearchIndex:
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=config.EMBEDDING_DIMENSIONS,
            vector_search_profile_name="default-vector-profile",
        ),
        SimpleField(name="source_filename", type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="page_number", type=SearchFieldDataType.Int32, filterable=True),
        SimpleField(name="section_title", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="content_type", type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="image_path", type=SearchFieldDataType.String),
        SimpleField(name="document_type", type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="data_source", type=SearchFieldDataType.String, filterable=True, facetable=True),
        # Collection(Edm.String) — a genuine list field, filtered with OData's
        # any() syntax in src/metadata_filter.py. This is the improvement
        # over the ChromaDB version's per-role boolean flattening hack.
        SimpleField(
            name="allowed_roles",
            type=SearchFieldDataType.Collection(SearchFieldDataType.String),
            filterable=True,
        ),
    ]

    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="default-hnsw")],
        profiles=[VectorSearchProfile(name="default-vector-profile", algorithm_configuration_name="default-hnsw")],
    )

    semantic_search = SemanticSearch(
        configurations=[
            SemanticConfiguration(
                name="default-semantic-config",
                prioritized_fields=SemanticPrioritizedFields(
                    title_field=SemanticField(field_name="section_title"),
                    content_fields=[SemanticField(field_name="content")],
                ),
            )
        ]
    )

    return SearchIndex(
        name=config.AZURE_SEARCH_INDEX_NAME,
        fields=fields,
        vector_search=vector_search,
        semantic_search=semantic_search,
    )


def main():
    if not config.AZURE_SEARCH_ENDPOINT or not config.AZURE_SEARCH_API_KEY:
        raise SystemExit(
            "AZURE_SEARCH_ENDPOINT / AZURE_SEARCH_API_KEY are not set in .env. "
            "Create the Search resource first — see README Step 4."
        )

    client = SearchIndexClient(
        endpoint=config.AZURE_SEARCH_ENDPOINT, credential=AzureKeyCredential(config.AZURE_SEARCH_API_KEY)
    )

    index = build_index_definition()
    result = client.create_or_update_index(index)
    print(f"Index '{result.name}' created/updated successfully.")
    print(f"  Vector dimensions: {config.EMBEDDING_DIMENSIONS}")
    print(f"  Semantic configuration: default-semantic-config")


if __name__ == "__main__":
    main()
