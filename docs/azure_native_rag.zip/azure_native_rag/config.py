"""
config.py
---------
Single source of truth for all configuration values — same role as in the
local-first version of this project, with one optional addition:
**secrets CAN come from Azure Key Vault instead of .env, if you set it up.**

How this works:
  - If KEY_VAULT_URL is set, every secret-shaped value below is fetched
    from Key Vault at import time, authenticating via
    DefaultAzureCredential (Managed Identity in Azure, or your `az login`
    session locally).
  - If KEY_VAULT_URL is NOT set — which is the DEFAULT for this project's
    deployment flow (infra/azure_setup.sh uses Azure Container Apps' own
    built-in secrets store instead, since Key Vault typically needs
    permissions beyond plain Contributor access — see README §6/§9),
    every value just comes straight from an environment variable, whether
    that's .env locally or a Container Apps secret once deployed.

This means the exact same code runs unmodified across all three cases —
local dev (.env), deployed without Key Vault (Container Apps secrets as
env vars), or deployed WITH Key Vault if you're later given the
permissions to set it up. Only the KEY_VAULT_URL value changes; the code
that reads config never does.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Key Vault bootstrap — must happen before anything else reads a secret
# ---------------------------------------------------------------------------
KEY_VAULT_URL = os.getenv("KEY_VAULT_URL", "")

_secret_cache: dict = {}

if KEY_VAULT_URL:
    # Imported only when actually needed, so local dev without Key Vault
    # configured never needs azure-identity/azure-keyvault-secrets to work.
    from azure.identity import DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient

    _credential = DefaultAzureCredential()
    _kv_client = SecretClient(vault_url=KEY_VAULT_URL, credential=_credential)


def _secret(name: str, env_var: str, default: str = "") -> str:
    """
    Resolve one config value: from Key Vault if KEY_VAULT_URL is set,
    otherwise from the environment variable. `name` is the Key Vault
    secret name (Key Vault secret names use hyphens, not underscores —
    e.g. "azure-openai-api-key" for AZURE_OPENAI_API_KEY); `env_var` is
    the .env variable name.

    Secrets are cached after first lookup so repeated config reads
    (this module is imported everywhere) don't repeatedly round-trip to
    Key Vault.
    """
    if not KEY_VAULT_URL:
        return os.getenv(env_var, default)

    if name not in _secret_cache:
        try:
            _secret_cache[name] = _kv_client.get_secret(name).value
        except Exception:
            # Fall back to .env if a specific secret isn't in Key Vault yet
            # (e.g. during initial setup) rather than crashing the whole app.
            _secret_cache[name] = os.getenv(env_var, default)

    return _secret_cache[name]


def _get_int(name: str, default: int) -> int:
    value = os.getenv(name)
    return int(value) if value else default


def _get_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    return value.lower() == "true" if value else default


# ---------------------------------------------------------------------------
# Azure Blob Storage
# ---------------------------------------------------------------------------
AZURE_STORAGE_CONNECTION_STRING = _secret("storage-connection-string", "AZURE_STORAGE_CONNECTION_STRING")
AZURE_STORAGE_CONTAINER = os.getenv("AZURE_STORAGE_CONTAINER", "rag-poc-docs")

# ---------------------------------------------------------------------------
# Azure AI Document Intelligence
# ---------------------------------------------------------------------------
DOCUMENT_INTELLIGENCE_ENDPOINT = os.getenv("DOCUMENT_INTELLIGENCE_ENDPOINT", "")
DOCUMENT_INTELLIGENCE_KEY = _secret("document-intelligence-key", "DOCUMENT_INTELLIGENCE_KEY")

# ---------------------------------------------------------------------------
# Azure OpenAI
# ---------------------------------------------------------------------------
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_KEY = _secret("azure-openai-api-key", "AZURE_OPENAI_API_KEY")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")

AZURE_OPENAI_EMBEDDING_DEPLOYMENT = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
AZURE_OPENAI_CHAT_FAST_DEPLOYMENT = os.getenv("AZURE_OPENAI_CHAT_FAST_DEPLOYMENT", "gpt-4o-mini")
AZURE_OPENAI_CHAT_ACCURATE_DEPLOYMENT = os.getenv("AZURE_OPENAI_CHAT_ACCURATE_DEPLOYMENT", "gpt-4o")
# Embedding vector size for text-embedding-3-small. Change this if you switch
# to a different embedding model/deployment — it must match exactly, since
# the Azure AI Search index's vector field is created with a fixed dimension.
EMBEDDING_DIMENSIONS = _get_int("EMBEDDING_DIMENSIONS", 1536)

# ---------------------------------------------------------------------------
# Azure AI Search
# ---------------------------------------------------------------------------
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "")
AZURE_SEARCH_API_KEY = _secret("azure-search-api-key", "AZURE_SEARCH_API_KEY")
AZURE_SEARCH_INDEX_NAME = os.getenv("AZURE_SEARCH_INDEX_NAME", "rag-poc-index")

# ---------------------------------------------------------------------------
# Application Insights
# ---------------------------------------------------------------------------
APPLICATIONINSIGHTS_CONNECTION_STRING = _secret(
    "applicationinsights-connection-string", "APPLICATIONINSIGHTS_CONNECTION_STRING"
)

# ---------------------------------------------------------------------------
# API authentication
# ---------------------------------------------------------------------------
API_KEY = _secret("api-key", "API_KEY")

# ---------------------------------------------------------------------------
# Local folders / logging
# ---------------------------------------------------------------------------
RAW_DOCS_DIR = os.getenv("RAW_DOCS_DIR", "data/raw_docs")
PROCESSED_DIR = os.getenv("PROCESSED_DIR", "data/processed")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = os.getenv("LOG_FILE", "logs/app.log")

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------
CHUNK_SIZE_CHARS = _get_int("CHUNK_SIZE_CHARS", 1500)
CHUNK_OVERLAP_CHARS = _get_int("CHUNK_OVERLAP_CHARS", 200)
MIN_CHUNK_LENGTH_CHARS = _get_int("MIN_CHUNK_LENGTH_CHARS", 40)
CLEANING_REMOVE_PATTERNS = [p.strip() for p in os.getenv("CLEANING_REMOVE_PATTERNS", "").split(",") if p.strip()]

# ---------------------------------------------------------------------------
# Incremental ingestion
# ---------------------------------------------------------------------------
ENABLE_INCREMENTAL_INGESTION = _get_bool("ENABLE_INCREMENTAL_INGESTION", True)
INGESTION_MANIFEST_PATH = os.getenv("INGESTION_MANIFEST_PATH", "data/processed/ingestion_manifest.json")

# ---------------------------------------------------------------------------
# Visual content track (diagrams, drawings, photos, DWG)
# ---------------------------------------------------------------------------
ENABLE_VISION_CAPTIONING = _get_bool("ENABLE_VISION_CAPTIONING", True)
MIN_IMAGE_PIXELS = _get_int("MIN_IMAGE_PIXELS", 40000)
ODA_FILE_CONVERTER_PATH = os.getenv("ODA_FILE_CONVERTER_PATH", "ODAFileConverter")

# ---------------------------------------------------------------------------
# Retrieval layer
# ---------------------------------------------------------------------------
ENABLE_ACL_FILTERING = _get_bool("ENABLE_ACL_FILTERING", True)
KNOWN_ROLES = [r.strip() for r in os.getenv("KNOWN_ROLES", "admin,employee").split(",") if r.strip()]

ENABLE_SEMANTIC_RANKING = _get_bool("ENABLE_SEMANTIC_RANKING", True)
INITIAL_RETRIEVAL_K = _get_int("INITIAL_RETRIEVAL_K", 20)
RERANK_TOP_N = _get_int("RERANK_TOP_N", 5)

CONTEXT_TOKEN_BUDGET = _get_int("CONTEXT_TOKEN_BUDGET", 2000)
DEDUP_SIMILARITY_THRESHOLD = float(os.getenv("DEDUP_SIMILARITY_THRESHOLD", "0.9"))

# ---------------------------------------------------------------------------
# Query processing
# ---------------------------------------------------------------------------
ENABLE_QUERY_REWRITE = _get_bool("ENABLE_QUERY_REWRITE", True)
QUERY_REWRITE_HISTORY_TURNS = _get_int("QUERY_REWRITE_HISTORY_TURNS", 3)

# ---------------------------------------------------------------------------
# LLM router
# ---------------------------------------------------------------------------
ENABLE_LLM_ROUTER = _get_bool("ENABLE_LLM_ROUTER", True)
ROUTER_COMPLEXITY_CHAR_THRESHOLD = _get_int("ROUTER_COMPLEXITY_CHAR_THRESHOLD", 200)
ROUTER_CONTEXT_CHUNK_THRESHOLD = _get_int("ROUTER_CONTEXT_CHUNK_THRESHOLD", 3)

# ---------------------------------------------------------------------------
# Guardrails
# ---------------------------------------------------------------------------
ENABLE_GUARDRAILS = _get_bool("ENABLE_GUARDRAILS", True)
GUARDRAIL_BLOCKED_TERMS = [t.strip().lower() for t in os.getenv("GUARDRAIL_BLOCKED_TERMS", "").split(",") if t.strip()]
GUARDRAIL_MIN_GROUNDING_RATIO = float(os.getenv("GUARDRAIL_MIN_GROUNDING_RATIO", "0.15"))

# ---------------------------------------------------------------------------
# Evaluation harness
# ---------------------------------------------------------------------------
EVAL_TEST_SET_PATH = os.getenv("EVAL_TEST_SET_PATH", "data/eval/test_questions.jsonl")
EVAL_REPORT_PATH = os.getenv("EVAL_REPORT_PATH", "reports/evaluation_report.json")
EVAL_LLM_JUDGE_ENABLED = _get_bool("EVAL_LLM_JUDGE_ENABLED", True)
