"""
scripts/convert_dwg.py
------------------------
Standalone helper to test your DWG conversion setup in isolation, before
running a full ingestion. Ingestion (scripts/ingest.py) converts DWG files
automatically as part of the pipeline — this script exists purely so you
can verify ODA File Converter is installed and working correctly on a
single file first, without waiting through a full ingestion run to find out.

Usage:
    python -m scripts.convert_dwg path/to/drawing.dwg
"""

import argparse
import sys

from src.dwg_converter import convert_dwg_to_pdf, is_converter_available
import config


def main():
    parser = argparse.ArgumentParser(description="Convert one DWG file to PDF, for testing the converter setup.")
    parser.add_argument("dwg_path", type=str)
    args = parser.parse_args()

    if not is_converter_available():
        print(f"ODA File Converter not found on PATH (looked for '{config.ODA_FILE_CONVERTER_PATH}').")
        print("See README 'DWG conversion setup' for installation instructions.")
        sys.exit(1)

    output_path = convert_dwg_to_pdf(args.dwg_path, "data/processed/dwg_converted")
    if output_path:
        print(f"Success: {output_path}")
    else:
        print("Conversion failed — check the logged error above.")
        sys.exit(1)


if __name__ == "__main__":
    main()
