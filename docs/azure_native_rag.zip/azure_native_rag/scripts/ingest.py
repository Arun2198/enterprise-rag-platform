"""
scripts/ingest.py
------------------
Command-line entry point for building the search index.

Usage:
    python -m scripts.ingest                  # download from Blob, then ingest
    python -m scripts.ingest --download-only   # only sync files from Blob Storage
    python -m scripts.ingest --skip-download   # ingest whatever is already in data/raw_docs
    python -m scripts.ingest --force-full      # ignore the incremental-ingestion manifest, reprocess everything

Before running this for the first time: make sure you've already run
`python -m infra.create_search_index` once (README Step 4), and
`python -m scripts.test_connections` to confirm everything is reachable.
"""

import argparse

import config
from src.blob_storage import download_container
from src.rag_pipeline import run_ingestion


def main():
    parser = argparse.ArgumentParser(description="Build the Azure AI Search index.")
    parser.add_argument("--download-only", action="store_true", help="Only download from Blob Storage; skip ingestion.")
    parser.add_argument("--skip-download", action="store_true", help="Skip Blob Storage download; ingest existing local files.")
    parser.add_argument(
        "--force-full",
        action="store_true",
        help="Ignore the incremental-ingestion manifest and reprocess every file "
             "(useful after changing chunking settings, which the file-hash check can't detect on its own).",
    )
    args = parser.parse_args()

    if args.force_full:
        config.ENABLE_INCREMENTAL_INGESTION = False
        print("Forcing a full re-ingestion (incremental skip-check disabled for this run).")

    if not args.skip_download:
        print("Step 1/2: Downloading source documents from Azure Blob Storage ...")
        download_container(config.RAW_DOCS_DIR)
    else:
        print("Skipping Blob Storage download (using existing files in data/raw_docs) ...")

    if args.download_only:
        print("Download-only mode: skipping ingestion.")
        return

    print("Step 2/2: Running ingestion (Document Intelligence + structured + vision tracks -> chunk -> embed -> index) ...")
    run_ingestion(config.RAW_DOCS_DIR)


if __name__ == "__main__":
    main()
