"""
scripts/evaluate.py
--------------------
Runs the evaluation harness against data/eval/test_questions.jsonl and
writes reports/evaluation_report.json. See src/evaluation.py for details.

Usage:
    python -m scripts.evaluate
"""

import json

from src.evaluation import run_evaluation


def main():
    report = run_evaluation()
    print("\n" + "=" * 60)
    print("EVALUATION SUMMARY")
    print("=" * 60)
    print(json.dumps(report["summary"], indent=2))
    print("\nFull per-question report written to reports/evaluation_report.json")


if __name__ == "__main__":
    main()
