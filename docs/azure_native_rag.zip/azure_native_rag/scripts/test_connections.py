"""
scripts/test_connections.py
----------------------------
Run this FIRST, before ingestion or querying, to confirm every Azure
resource is wired up correctly. Each check runs independently and reports
pass/fail with the specific error, so a misconfigured .env value points
you straight at the problem instead of surfacing halfway through a long
(and now, cost-incurring) ingestion run.

Usage:
    python -m scripts.test_connections
"""

import sys

import config


def check(label: str, fn) -> bool:
    print(f"Testing: {label} ... ", end="", flush=True)
    try:
        fn()
        print("OK")
        return True
    except Exception as exc:
        print("FAILED")
        print(f"    -> {type(exc).__name__}: {exc}")
        return False


def test_blob_storage():
    from azure.storage.blob import BlobServiceClient

    client = BlobServiceClient.from_connection_string(config.AZURE_STORAGE_CONNECTION_STRING)
    container_client = client.get_container_client(config.AZURE_STORAGE_CONTAINER)
    list(container_client.list_blobs())


def test_document_intelligence():
    from azure.ai.documentintelligence import DocumentIntelligenceClient
    from azure.core.credentials import AzureKeyCredential

    client = DocumentIntelligenceClient(
        endpoint=config.DOCUMENT_INTELLIGENCE_ENDPOINT, credential=AzureKeyCredential(config.DOCUMENT_INTELLIGENCE_KEY)
    )
    # get_resource_details() is a lightweight call that confirms the
    # endpoint/key are valid without actually analyzing a document.
    client.get_resource_details()


def test_azure_openai_embeddings():
    from src.embedder import embed_single_text

    vector = embed_single_text("connection test")
    if len(vector) != config.EMBEDDING_DIMENSIONS:
        raise ValueError(
            f"Embedding returned {len(vector)} dimensions, expected {config.EMBEDDING_DIMENSIONS} "
            "— check AZURE_OPENAI_EMBEDDING_DEPLOYMENT matches EMBEDDING_DIMENSIONS in .env."
        )


def test_azure_openai_chat():
    from src.llm_client import complete

    response = complete("Reply with exactly one word: pong")
    if not response.strip():
        raise ValueError("Azure OpenAI chat deployment returned an empty response.")


def test_azure_search():
    from src.vector_store import VectorStore

    store = VectorStore()
    store.count()  # confirms the index exists and is queryable


def test_key_vault():
    if not config.KEY_VAULT_URL:
        print("SKIPPED (KEY_VAULT_URL not set — using .env directly, which is fine for local dev)", end="")
        return

    from azure.identity import DefaultAzureCredential
    from azure.keyvault.secrets import SecretClient

    client = SecretClient(vault_url=config.KEY_VAULT_URL, credential=DefaultAzureCredential())
    list(client.list_properties_of_secrets())


def test_dwg_converter():
    from src.dwg_converter import is_converter_available

    if not is_converter_available():
        print(
            "SKIPPED (ODA File Converter not found — DWG files will be skipped with a "
            "warning during ingestion; see README 'DWG conversion setup' if you have DWG files to process)",
            end="",
        )


def main():
    results = []
    results.append(check("Azure Blob Storage", test_blob_storage))
    results.append(check("Azure AI Document Intelligence", test_document_intelligence))
    results.append(check("Azure OpenAI — embeddings", test_azure_openai_embeddings))
    results.append(check("Azure OpenAI — chat", test_azure_openai_chat))
    results.append(check("Azure AI Search", test_azure_search))
    results.append(check("Azure Key Vault", test_key_vault))
    results.append(check("ODA File Converter (DWG support)", test_dwg_converter))

    print()
    if all(results):
        print("All checks passed (or were intentionally skipped). Safe to run: python -m scripts.ingest")
        sys.exit(0)
    else:
        print("One or more checks failed. Fix the issue above before running ingestion.")
        sys.exit(1)


if __name__ == "__main__":
    main()
