# Makes "scripts" a Python package so it can be run as "python -m scripts.ingest"
