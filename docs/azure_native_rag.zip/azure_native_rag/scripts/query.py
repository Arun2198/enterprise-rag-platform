"""
scripts/query.py
-----------------
Command-line entry point for asking questions.

Single-shot:
    python -m scripts.query "What does the inspection report say about corrosion?"

With RBAC role and metadata filters:
    python -m scripts.query "What are the Q3 numbers?" --role employee --document-type financial

Multi-turn interactive mode:
    python -m scripts.query --interactive
"""

import argparse
import json

from src.rag_pipeline import run_query
from src.query_processor import ChatTurn


def _print_result(result: dict) -> None:
    if result.get("blocked"):
        print(f"\n[BLOCKED] {result['block_reason']}")
        return

    if result.get("rewritten_question"):
        print(f"\n(Rewritten query used for retrieval: \"{result['rewritten_question']}\")")

    print("\n" + "=" * 60)
    print("ANSWER:")
    print(result["answer"])
    print("=" * 60)

    if result.get("routing"):
        print(f"Model tier used: {result['routing']['tier']} ({result['routing']['reason']})")
    if result.get("grounding_warning"):
        print(f"\n[GUARDRAIL WARNING] {result['grounding_warning']}")
    if result.get("sources"):
        print("\nSOURCES USED:")
        print(json.dumps(result["sources"], indent=2))


def _run_single_shot(args) -> None:
    result = run_query(
        question=args.question, user_roles=args.role, document_type=args.document_type, data_source=args.data_source
    )
    _print_result(result)


def _run_interactive(args) -> None:
    print("Interactive mode. Type 'exit' or 'quit' to stop.\n")
    history: list[ChatTurn] = []

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if question.lower() in {"exit", "quit"}:
            break
        if not question:
            continue

        result = run_query(
            question=question, history=history, user_roles=args.role,
            document_type=args.document_type, data_source=args.data_source,
        )
        _print_result(result)

        if not result.get("blocked") and result.get("answer"):
            history.append(ChatTurn(question=question, answer=result["answer"]))


def main():
    parser = argparse.ArgumentParser(description="Ask a question against the search index.")
    parser.add_argument("question", type=str, nargs="?", help="The question to ask (omit if using --interactive).")
    parser.add_argument("--role", type=str, action="append", default=None, help="Simulate the querying user's role (repeatable).")
    parser.add_argument("--document-type", type=str, default=None)
    parser.add_argument("--data-source", type=str, default=None)
    parser.add_argument("--interactive", action="store_true")
    args = parser.parse_args()

    if args.interactive:
        _run_interactive(args)
    else:
        if not args.question:
            parser.error("A question is required unless --interactive is used.")
        _run_single_shot(args)


if __name__ == "__main__":
    main()
