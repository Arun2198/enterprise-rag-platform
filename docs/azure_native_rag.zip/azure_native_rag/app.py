"""
app.py
------
The public-facing API — this is what makes the system "reachable by other
people," running on Azure Container Apps (see README Step 8).

Every route except /health requires the X-API-Key header (src/auth.py) —
the deliberately-simple protection choice from the design discussion,
instead of Azure API Management.

Run locally with:
    uvicorn app:app --reload --port 8000
"""

from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel

from src.rag_pipeline import run_query, run_ingestion
from src.query_processor import ChatTurn
from src.embedder import embed_single_text
from src.vector_store import get_vector_store
from src.auth import require_api_key
from src.logging_setup import get_logger

logger = get_logger()
app = FastAPI(title="Azure-Native RAG POC API")


@app.on_event("startup")
def warm_up():
    """
    Pre-load whatever can be pre-loaded (the Azure OpenAI client, the
    Azure AI Search client) once at container startup, rather than paying
    that setup cost on whichever request happens to arrive first.
    """
    logger.info("Warming up clients ...")
    try:
        embed_single_text("startup warm-up")
        get_vector_store()
        logger.info("Warm-up complete.")
    except Exception as exc:
        # Don't crash the whole app if warm-up fails (e.g. index not
        # created yet) — let it come up and fail per-request with a
        # clearer error instead, so /health still works for diagnostics.
        logger.warning(f"Warm-up failed (app will still start): {exc}")


class HistoryTurn(BaseModel):
    question: str
    answer: str


class QueryRequest(BaseModel):
    question: str
    history: list[HistoryTurn] | None = None
    roles: list[str] | None = None
    document_type: str | None = None
    data_source: str | None = None


class QueryResponse(BaseModel):
    question: str
    rewritten_question: str | None = None
    answer: str | None
    sources: list
    blocked: bool = False
    block_reason: str | None = None
    routing: dict | None = None
    grounding_warning: str | None = None


@app.post("/ingest", dependencies=[Depends(require_api_key)])
def ingest_endpoint():
    """
    Triggers ingestion over whatever is currently in data/raw_docs.
    Note: on Container Apps, data/raw_docs is ephemeral container storage
    unless you've mounted a persistent volume — for a real deployment,
    sync from Blob Storage first (scripts/ingest.py handles this via
    --skip-download vs. the default download-then-ingest behavior; this
    endpoint assumes files are already present).
    """
    try:
        run_ingestion()
        return {"status": "ok", "message": "Ingestion complete."}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/query", response_model=QueryResponse, dependencies=[Depends(require_api_key)])
def query_endpoint(request: QueryRequest):
    try:
        history = [ChatTurn(question=t.question, answer=t.answer) for t in request.history] if request.history else None
        result = run_query(
            question=request.question,
            history=history,
            user_roles=request.roles,
            document_type=request.document_type,
            data_source=request.data_source,
        )
        return result
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/health")
def health_check():
    """Unauthenticated on purpose — Container Apps' health probe needs to reach this without a key."""
    return {"status": "healthy"}
