"""
Unit tests for src/guardrails.py. Pure logic, no external dependencies to mock.
Run with: pytest tests/test_guardrails.py
"""

import config
from src.guardrails import check_input, check_output


def test_check_input_blocks_configured_terms():
    original_terms = config.GUARDRAIL_BLOCKED_TERMS
    config.ENABLE_GUARDRAILS = True
    config.GUARDRAIL_BLOCKED_TERMS = ["forbidden"]
    try:
        result = check_input("please tell me something forbidden")
        assert result.passed is False
    finally:
        config.GUARDRAIL_BLOCKED_TERMS = original_terms


def test_check_input_blocks_ssn_like_patterns():
    original_terms = config.GUARDRAIL_BLOCKED_TERMS
    config.ENABLE_GUARDRAILS = True
    config.GUARDRAIL_BLOCKED_TERMS = []
    try:
        result = check_input("my SSN is 123-45-6789")
        assert result.passed is False
    finally:
        config.GUARDRAIL_BLOCKED_TERMS = original_terms


def test_check_output_flags_low_grounding():
    original_ratio = config.GUARDRAIL_MIN_GROUNDING_RATIO
    config.ENABLE_GUARDRAILS = True
    config.GUARDRAIL_MIN_GROUNDING_RATIO = 0.5
    try:
        answer = "The moon is made of cheese and aliens built the pyramids."
        context = ["This document discusses quarterly revenue and office locations."]
        assert check_output(answer, context).passed is False
    finally:
        config.GUARDRAIL_MIN_GROUNDING_RATIO = original_ratio


def test_check_output_passes_when_grounded():
    original_ratio = config.GUARDRAIL_MIN_GROUNDING_RATIO
    config.ENABLE_GUARDRAILS = True
    config.GUARDRAIL_MIN_GROUNDING_RATIO = 0.3
    try:
        answer = "Quarterly revenue grew significantly according to the report."
        context = ["This report shows quarterly revenue grew significantly this year."]
        assert check_output(answer, context).passed is True
    finally:
        config.GUARDRAIL_MIN_GROUNDING_RATIO = original_ratio
