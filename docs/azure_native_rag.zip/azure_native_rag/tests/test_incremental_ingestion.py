"""
Unit tests for src/incremental_ingestion.py — content-hash based change
detection. Uses real temp files (hashing is inherently file-based) but no
Azure dependencies, so no mocking needed.
Run with: pytest tests/test_incremental_ingestion.py
"""

import json
import os
import tempfile

import config
from src.incremental_ingestion import filter_changed_files, load_manifest, save_manifest


def test_first_run_treats_all_files_as_changed():
    with tempfile.TemporaryDirectory() as tmp_dir:
        original_raw_dir = config.RAW_DOCS_DIR
        original_manifest_path = config.INGESTION_MANIFEST_PATH
        original_incremental = config.ENABLE_INCREMENTAL_INGESTION
        config.RAW_DOCS_DIR = tmp_dir
        config.INGESTION_MANIFEST_PATH = os.path.join(tmp_dir, "manifest.json")
        config.ENABLE_INCREMENTAL_INGESTION = True

        try:
            file_path = os.path.join(tmp_dir, "report.pdf")
            with open(file_path, "w") as f:
                f.write("some content")

            changed, manifest = filter_changed_files([file_path])

            assert changed == [file_path]
            assert "report.pdf" in manifest
        finally:
            config.RAW_DOCS_DIR = original_raw_dir
            config.INGESTION_MANIFEST_PATH = original_manifest_path
            config.ENABLE_INCREMENTAL_INGESTION = original_incremental


def test_unchanged_file_is_skipped_on_second_run():
    with tempfile.TemporaryDirectory() as tmp_dir:
        original_raw_dir = config.RAW_DOCS_DIR
        original_manifest_path = config.INGESTION_MANIFEST_PATH
        original_incremental = config.ENABLE_INCREMENTAL_INGESTION
        config.RAW_DOCS_DIR = tmp_dir
        config.INGESTION_MANIFEST_PATH = os.path.join(tmp_dir, "manifest.json")
        config.ENABLE_INCREMENTAL_INGESTION = True

        try:
            file_path = os.path.join(tmp_dir, "report.pdf")
            with open(file_path, "w") as f:
                f.write("some content")

            _, manifest = filter_changed_files([file_path])
            save_manifest(manifest)

            # Second run, file unchanged -> should be skipped
            changed_again, _ = filter_changed_files([file_path])
            assert changed_again == []
        finally:
            config.RAW_DOCS_DIR = original_raw_dir
            config.INGESTION_MANIFEST_PATH = original_manifest_path
            config.ENABLE_INCREMENTAL_INGESTION = original_incremental


def test_modified_file_is_detected_as_changed():
    with tempfile.TemporaryDirectory() as tmp_dir:
        original_raw_dir = config.RAW_DOCS_DIR
        original_manifest_path = config.INGESTION_MANIFEST_PATH
        original_incremental = config.ENABLE_INCREMENTAL_INGESTION
        config.RAW_DOCS_DIR = tmp_dir
        config.INGESTION_MANIFEST_PATH = os.path.join(tmp_dir, "manifest.json")
        config.ENABLE_INCREMENTAL_INGESTION = True

        try:
            file_path = os.path.join(tmp_dir, "report.pdf")
            with open(file_path, "w") as f:
                f.write("original content")

            _, manifest = filter_changed_files([file_path])
            save_manifest(manifest)

            with open(file_path, "w") as f:
                f.write("modified content")

            changed_again, _ = filter_changed_files([file_path])
            assert changed_again == [file_path]
        finally:
            config.RAW_DOCS_DIR = original_raw_dir
            config.INGESTION_MANIFEST_PATH = original_manifest_path
            config.ENABLE_INCREMENTAL_INGESTION = original_incremental


def test_disabling_incremental_mode_forces_full_reingestion():
    with tempfile.TemporaryDirectory() as tmp_dir:
        original_raw_dir = config.RAW_DOCS_DIR
        original_manifest_path = config.INGESTION_MANIFEST_PATH
        original_incremental = config.ENABLE_INCREMENTAL_INGESTION
        config.RAW_DOCS_DIR = tmp_dir
        config.INGESTION_MANIFEST_PATH = os.path.join(tmp_dir, "manifest.json")

        try:
            file_path = os.path.join(tmp_dir, "report.pdf")
            with open(file_path, "w") as f:
                f.write("content")

            config.ENABLE_INCREMENTAL_INGESTION = True
            _, manifest = filter_changed_files([file_path])
            save_manifest(manifest)

            config.ENABLE_INCREMENTAL_INGESTION = False
            changed_again, _ = filter_changed_files([file_path])
            assert changed_again == [file_path]  # forced full re-ingestion, unchanged file still included
        finally:
            config.RAW_DOCS_DIR = original_raw_dir
            config.INGESTION_MANIFEST_PATH = original_manifest_path
            config.ENABLE_INCREMENTAL_INGESTION = original_incremental
