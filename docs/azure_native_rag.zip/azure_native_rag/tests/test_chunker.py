"""
Unit tests for src/chunker.py. Pure logic, no external dependencies to mock.
Run with: pytest tests/test_chunker.py
"""

from src.chunker import chunk_documents
from src.document_loader import LoadedDocument, Section


def test_chunk_documents_produces_chunks_with_provenance():
    doc = LoadedDocument(
        source_filename="sample.pdf",
        sections=[Section(text="A" * 2000, page_number=1, section_title=None, content_type="text")],
        document_type="general",
        data_source="local_upload",
        allowed_roles=["admin", "employee"],
    )

    chunks = chunk_documents([doc])

    assert len(chunks) > 1
    for chunk in chunks:
        assert chunk.source_filename == "sample.pdf"
        assert chunk.page_number == 1
        assert chunk.content_type == "text"
        assert chunk.allowed_roles == ["admin", "employee"]
        assert chunk.chunk_id


def test_chunk_documents_drops_short_fragments():
    doc = LoadedDocument(source_filename="sample.html", sections=[Section(text="short")])
    assert chunk_documents([doc]) == []


def test_chunk_documents_preserves_visual_content_type_and_image_path():
    doc = LoadedDocument(
        source_filename="drawing.pdf",
        sections=[
            Section(
                text="A structural drawing showing a beam cross-section labeled 300x600mm, dimensions in millimeters.",
                page_number=2,
                section_title="Embedded diagram/image",
                content_type="visual",
                image_path="data/processed/extracted_images/drawing_p2_i0.png",
            )
        ],
    )

    chunks = chunk_documents([doc])

    assert len(chunks) == 1
    assert chunks[0].content_type == "visual"
    assert chunks[0].image_path == "data/processed/extracted_images/drawing_p2_i0.png"


def test_chunk_documents_carries_section_title_from_sheet_names():
    doc = LoadedDocument(
        source_filename="readings.xlsx",
        sections=[
            Section(text="date: 2026-01-01, reading: 45.2, unit: psi " * 5, page_number=None, section_title="Sheet1"),
            Section(text="date: 2026-01-02, reading: 46.1, unit: psi " * 5, page_number=None, section_title="Sheet2"),
        ],
    )

    chunks = chunk_documents([doc])
    section_titles = {c.section_title for c in chunks}

    assert "Sheet1" in section_titles
    assert "Sheet2" in section_titles
