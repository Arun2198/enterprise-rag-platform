"""
Unit tests for src/metadata_filter.py — OData filter string construction
for Azure AI Search. Pure logic, no external dependencies to mock.
Run with: pytest tests/test_metadata_filter.py
"""

import config
from src.metadata_filter import build_where_clause, _escape


def test_escape_doubles_single_quotes():
    assert _escape("O'Brien") == "O''Brien"
    assert _escape("plain") == "plain"


def test_build_where_clause_returns_none_when_no_filters_and_acl_disabled():
    original = config.ENABLE_ACL_FILTERING
    config.ENABLE_ACL_FILTERING = False
    try:
        assert build_where_clause(user_roles=["employee"]) is None
    finally:
        config.ENABLE_ACL_FILTERING = original


def test_build_where_clause_single_role_no_parens():
    original_acl = config.ENABLE_ACL_FILTERING
    original_roles = config.KNOWN_ROLES
    config.ENABLE_ACL_FILTERING = True
    config.KNOWN_ROLES = ["admin", "employee"]
    try:
        clause = build_where_clause(user_roles=["admin"])
        assert clause == "allowed_roles/any(r: r eq 'admin')"
    finally:
        config.ENABLE_ACL_FILTERING = original_acl
        config.KNOWN_ROLES = original_roles


def test_build_where_clause_multiple_roles_ored_together():
    original_acl = config.ENABLE_ACL_FILTERING
    original_roles = config.KNOWN_ROLES
    config.ENABLE_ACL_FILTERING = True
    config.KNOWN_ROLES = ["admin", "employee"]
    try:
        clause = build_where_clause(user_roles=["admin", "employee"])
        assert clause == "(allowed_roles/any(r: r eq 'admin') or allowed_roles/any(r: r eq 'employee'))"
    finally:
        config.ENABLE_ACL_FILTERING = original_acl
        config.KNOWN_ROLES = original_roles


def test_build_where_clause_combines_acl_and_document_type_with_and():
    original_acl = config.ENABLE_ACL_FILTERING
    original_roles = config.KNOWN_ROLES
    config.ENABLE_ACL_FILTERING = True
    config.KNOWN_ROLES = ["admin"]
    try:
        clause = build_where_clause(user_roles=["admin"], document_type="financial")
        assert clause == "allowed_roles/any(r: r eq 'admin') and document_type eq 'financial'"
    finally:
        config.ENABLE_ACL_FILTERING = original_acl
        config.KNOWN_ROLES = original_roles


def test_build_where_clause_ignores_unknown_roles():
    original_acl = config.ENABLE_ACL_FILTERING
    original_roles = config.KNOWN_ROLES
    config.ENABLE_ACL_FILTERING = True
    config.KNOWN_ROLES = ["admin", "employee"]
    try:
        clause = build_where_clause(user_roles=["not_a_real_role"])
        assert clause is None  # no valid roles -> no ACL clause added
    finally:
        config.ENABLE_ACL_FILTERING = original_acl
        config.KNOWN_ROLES = original_roles
