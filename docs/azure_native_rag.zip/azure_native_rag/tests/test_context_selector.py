"""
Unit tests for src/context_selector.py — deduplication and token budgeting.
Pure logic, no external dependencies to mock.
Run with: pytest tests/test_context_selector.py
"""

from dataclasses import dataclass

import config
from src.context_selector import deduplicate, select_context


@dataclass
class FakeCandidate:
    chunk_id: str
    text: str
    metadata: dict


def test_deduplicate_drops_near_identical_chunks_keeping_first():
    a = FakeCandidate("1", "The quarterly revenue grew by twelve percent this year.", {})
    b = FakeCandidate("2", "The quarterly revenue grew by twelve percent this year!", {})
    c = FakeCandidate("3", "Completely unrelated content about office locations.", {})

    result = deduplicate([a, b, c])
    assert [r.chunk_id for r in result] == ["1", "3"]


def test_select_context_stops_once_token_budget_exceeded():
    chunks = [FakeCandidate(str(i), "word " * 80, {"source_filename": f"doc{i}.pdf"}) for i in range(5)]
    selected = select_context(chunks, token_budget=250)
    assert 1 <= len(selected) < 5


def test_select_context_preserves_metadata():
    chunks = [FakeCandidate("1", "Some reasonably long piece of context text.", {"source_filename": "a.pdf", "content_type": "text"})]
    selected = select_context(chunks, token_budget=config.CONTEXT_TOKEN_BUDGET)
    assert len(selected) == 1
    assert selected[0].metadata["content_type"] == "text"
