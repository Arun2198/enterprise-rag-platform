"""
Unit tests for src/vector_store.py, with the Azure AI Search SDK mocked
out — same principle as the local-first version's ChromaDB mocking: patch
the external SDK, assert our code calls it correctly, no real Azure
resource or network access needed.
Run with: pytest tests/test_vector_store.py
"""

from unittest.mock import MagicMock, patch


@patch("src.vector_store.SearchClient")
def test_add_builds_documents_with_expected_schema(mock_search_client_cls):
    mock_client = MagicMock()
    mock_client.upload_documents.return_value = [MagicMock(succeeded=True)]
    mock_search_client_cls.return_value = mock_client

    import config

    original_endpoint = config.AZURE_SEARCH_ENDPOINT
    original_key = config.AZURE_SEARCH_API_KEY
    config.AZURE_SEARCH_ENDPOINT = "https://fake.search.windows.net"
    config.AZURE_SEARCH_API_KEY = "fake-key"

    try:
        from src.vector_store import VectorStore

        store = VectorStore()
        store.add(
            ids=["chunk_1"],
            embeddings=[[0.1, 0.2]],
            documents=["some text"],
            metadatas=[
                {
                    "source_filename": "a.pdf",
                    "page_number": 3,
                    "content_type": "text",
                    "allowed_roles": ["admin"],
                    "document_type": "general",
                    "data_source": "local_upload",
                }
            ],
        )

        _, kwargs = mock_client.upload_documents.call_args
        uploaded_doc = kwargs["documents"][0]

        assert uploaded_doc["id"] == "chunk_1"
        assert uploaded_doc["content"] == "some text"
        assert uploaded_doc["content_vector"] == [0.1, 0.2]
        assert uploaded_doc["allowed_roles"] == ["admin"]  # stored as a real list, no flattening needed
        assert uploaded_doc["page_number"] == 3
    finally:
        config.AZURE_SEARCH_ENDPOINT = original_endpoint
        config.AZURE_SEARCH_API_KEY = original_key


@patch("src.vector_store.SearchClient")
def test_add_omits_none_page_number_rather_than_sending_null(mock_search_client_cls):
    mock_client = MagicMock()
    mock_client.upload_documents.return_value = [MagicMock(succeeded=True)]
    mock_search_client_cls.return_value = mock_client

    import config

    original_endpoint = config.AZURE_SEARCH_ENDPOINT
    original_key = config.AZURE_SEARCH_API_KEY
    config.AZURE_SEARCH_ENDPOINT = "https://fake.search.windows.net"
    config.AZURE_SEARCH_API_KEY = "fake-key"

    try:
        from src.vector_store import VectorStore

        store = VectorStore()
        store.add(
            ids=["chunk_1"],
            embeddings=[[0.1, 0.2]],
            documents=["xlsx row data"],
            metadatas=[{"source_filename": "data.xlsx", "page_number": None}],
        )

        _, kwargs = mock_client.upload_documents.call_args
        uploaded_doc = kwargs["documents"][0]
        assert "page_number" not in uploaded_doc
    finally:
        config.AZURE_SEARCH_ENDPOINT = original_endpoint
        config.AZURE_SEARCH_API_KEY = original_key


@patch("src.vector_store.SearchClient")
def test_query_passes_filter_and_semantic_config_through(mock_search_client_cls):
    mock_client = MagicMock()
    mock_client.search.return_value = []
    mock_search_client_cls.return_value = mock_client

    import config

    original_endpoint = config.AZURE_SEARCH_ENDPOINT
    original_key = config.AZURE_SEARCH_API_KEY
    original_semantic = config.ENABLE_SEMANTIC_RANKING
    config.AZURE_SEARCH_ENDPOINT = "https://fake.search.windows.net"
    config.AZURE_SEARCH_API_KEY = "fake-key"
    config.ENABLE_SEMANTIC_RANKING = True

    try:
        from src.vector_store import VectorStore

        store = VectorStore()
        store.query(query_embedding=[0.1, 0.2], top_k=5, where="document_type eq 'financial'")

        _, kwargs = mock_client.search.call_args
        assert kwargs["filter"] == "document_type eq 'financial'"
        assert kwargs["query_type"] == "semantic"
        assert kwargs["semantic_configuration_name"] == "default-semantic-config"
        assert kwargs["top"] == 5
    finally:
        config.AZURE_SEARCH_ENDPOINT = original_endpoint
        config.AZURE_SEARCH_API_KEY = original_key
        config.ENABLE_SEMANTIC_RANKING = original_semantic
