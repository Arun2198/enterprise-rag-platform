"""
structured_loader.py
---------------------
Parses XLSX and CSV files directly with pandas — deliberately NOT routed
through Document Intelligence. Reasoning (from the design discussion):
this data is already perfectly structured; running it through a
document-understanding service would cost money to re-derive something
you can already read with 100% accuracy for free.

If an Excel file contains embedded CHART images (not just data tables),
those charts still need the visual track (vision captioning) — this
module only handles the tabular data itself. Chart extraction from XLSX
is out of scope for the current version; flagged in README as a known gap.
"""

import os

import pandas as pd

from src.logging_setup import get_logger

logger = get_logger()


def load_xlsx(path: str) -> list[dict]:
    """
    One "page" dict per sheet: {"page_number": None, "text": ..., "section_title": sheet_name}.
    Rows are flattened into "column: value" lines so numeric data becomes searchable text.
    """
    filename = os.path.basename(path)
    try:
        all_sheets = pd.read_excel(path, sheet_name=None)
    except Exception as exc:
        logger.error(f"Failed to read {filename}: {exc}")
        return []

    pages = []
    for sheet_name, df in all_sheets.items():
        rows_text = [", ".join(f"{col}: {val}" for col, val in row.items()) for _, row in df.iterrows()]
        text = "\n".join(rows_text)
        if text.strip():
            pages.append({"page_number": None, "text": text, "section_title": sheet_name})

    return pages


def load_csv(path: str) -> list[dict]:
    """One "page" for the whole file, same row-flattening approach as XLSX."""
    filename = os.path.basename(path)
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        logger.error(f"Failed to read {filename}: {exc}")
        return []

    rows_text = [", ".join(f"{col}: {val}" for col, val in row.items()) for _, row in df.iterrows()]
    text = "\n".join(rows_text)
    return [{"page_number": None, "text": text, "section_title": None}] if text.strip() else []
