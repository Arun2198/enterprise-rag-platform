# Makes "src" a Python package so modules can be imported as e.g.
# "from src.document_loader import load_documents"
