"""
vision_captioner.py
--------------------
Turns an image (a diagram, a structural drawing, a photo of a gauge/meter,
a DWG-derived page) into a plain-text description using an Azure OpenAI
vision-capable chat model. That description then becomes a normal,
embeddable, searchable chunk — same as any text chunk — with the original
image path kept alongside it so a user can be shown the actual picture,
not just a description of one.

Two tiers, matching the design discussion:
  - `caption_image()` uses the FAST/cheap deployment (gpt-4o-mini, which
    has vision built in) — meant for bulk captioning of potentially
    thousands of images during ingestion.
  - `caption_image_high_fidelity()` uses the ACCURATE deployment (gpt-4o)
    — meant to be called sparingly, e.g. at query time when a user asks a
    specific question about a retrieved image and the cached caption
    might not have the detail needed to answer it precisely.

Both functions share the same prompt/parsing logic; only the deployment
differs.

A known, honest limitation carried over from the design discussion: this
can usually read a DIGITAL display accurately, but an ANALOG needle gauge
is unreliable for any general-purpose vision model to read precisely.
Don't treat a captioned analog reading as ground truth without spot-checking.
"""

import base64
import mimetypes

from openai import AzureOpenAI

import config
from src.logging_setup import get_logger

logger = get_logger()

_client: AzureOpenAI | None = None


def _get_client() -> AzureOpenAI:
    global _client
    if _client is None:
        _client = AzureOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
        )
    return _client


_CAPTION_PROMPT = (
    "Describe what this image shows, in plain text, for someone who cannot see it. "
    "This may be a structural/engineering drawing, a diagram, a photo of an inspection "
    "site, or a photo of a gauge/meter/nameplate. Be specific: transcribe any visible "
    "labels, dimensions, part numbers, or readings exactly as written. If it's a chart or "
    "graph, describe the trend and any axis labels/values you can read. If a reading is on "
    "an analog dial/needle gauge, describe your best estimate but note it's an estimate, "
    "not an exact digital reading."
)


def _encode_image(image_path: str) -> str:
    """Read an image file and return it as a base64 data URL, the format Azure OpenAI's vision input expects."""
    mime_type = mimetypes.guess_type(image_path)[0] or "image/png"
    with open(image_path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime_type};base64,{encoded}"


def _caption(image_path: str, deployment: str) -> str:
    client = _get_client()
    data_url = _encode_image(image_path)

    response = client.chat.completions.create(
        model=deployment,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": _CAPTION_PROMPT},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            }
        ],
        temperature=0.2,  # low temperature: this is a description task, not a creative one
        max_tokens=500,
    )
    return response.choices[0].message.content.strip()


def caption_image(image_path: str) -> str:
    """Bulk/cheap captioning for ingestion-time use — see module docstring."""
    try:
        return _caption(image_path, config.AZURE_OPENAI_CHAT_FAST_DEPLOYMENT)
    except Exception as exc:
        logger.error(f"Vision captioning failed for {image_path}: {exc}")
        return ""


def caption_image_high_fidelity(image_path: str, question: str | None = None) -> str:
    """
    Higher-quality captioning, meant to be called sparingly (e.g. at query
    time for a specific retrieved image), optionally focused on a specific
    question the user asked about the image.
    """
    prompt = _CAPTION_PROMPT
    if question:
        prompt += f"\n\nThe user specifically asked: \"{question}\" — prioritize details relevant to answering that."

    try:
        client = _get_client()
        data_url = _encode_image(image_path)
        response = client.chat.completions.create(
            model=config.AZURE_OPENAI_CHAT_ACCURATE_DEPLOYMENT,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }
            ],
            temperature=0.2,
            max_tokens=800,
        )
        return response.choices[0].message.content.strip()
    except Exception as exc:
        logger.error(f"High-fidelity vision captioning failed for {image_path}: {exc}")
        return ""
