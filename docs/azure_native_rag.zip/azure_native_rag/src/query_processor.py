"""
query_processor.py
-------------------
Rewrites a follow-up question into a standalone form using recent chat
history, BEFORE it's embedded and searched — unchanged in logic from the
local-first version. Uses llm_client.complete() (now Azure OpenAI only),
so no plumbing changes were needed here beyond the import.
"""

from dataclasses import dataclass

import config
from src.llm_client import complete


@dataclass
class ChatTurn:
    question: str
    answer: str


def _format_history(history: list[ChatTurn]) -> str:
    recent = history[-config.QUERY_REWRITE_HISTORY_TURNS:]
    lines = []
    for turn in recent:
        lines.append(f"User: {turn.question}")
        lines.append(f"Assistant: {turn.answer}")
    return "\n".join(lines)


def contextualize_query(question: str, history: list[ChatTurn] | None = None) -> str:
    if not config.ENABLE_QUERY_REWRITE or not history:
        return question

    history_text = _format_history(history)
    rewrite_instruction = (
        "Rewrite the user's latest question into a fully standalone question "
        "that makes sense without the conversation history, by resolving "
        "pronouns and implicit references (e.g. 'it', 'the second one', "
        "'that report'). Do NOT answer the question — only output the "
        "rewritten question, nothing else.\n\n"
        f"Conversation so far:\n{history_text}\n\n"
        f"Latest question: {question}"
    )

    rewritten = complete(rewrite_instruction)
    return rewritten.strip() if rewritten.strip() else question
