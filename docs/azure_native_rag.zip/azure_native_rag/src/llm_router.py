"""
llm_router.py
-------------
Routes each request to the fast (gpt-4o-mini) or accurate (gpt-4o) Azure
OpenAI deployment based on simple, transparent rules — unchanged in logic
from the local-first version, just pointed at two Azure deployments
instead of two Ollama models.
"""

from dataclasses import dataclass

import config


@dataclass
class RoutingDecision:
    model_override: str | None
    tier: str
    reason: str


def route(question: str, num_context_chunks: int) -> RoutingDecision:
    if not config.ENABLE_LLM_ROUTER:
        return RoutingDecision(model_override=None, tier="default", reason="router disabled")

    is_long_question = len(question) > config.ROUTER_COMPLEXITY_CHAR_THRESHOLD
    needs_lots_of_context = num_context_chunks > config.ROUTER_CONTEXT_CHUNK_THRESHOLD

    if is_long_question or needs_lots_of_context:
        reason_parts = []
        if is_long_question:
            reason_parts.append(f"question length {len(question)} > {config.ROUTER_COMPLEXITY_CHAR_THRESHOLD}")
        if needs_lots_of_context:
            reason_parts.append(f"{num_context_chunks} context chunks > {config.ROUTER_CONTEXT_CHUNK_THRESHOLD}")
        return RoutingDecision(
            model_override=config.AZURE_OPENAI_CHAT_ACCURATE_DEPLOYMENT,
            tier="accurate",
            reason=" and ".join(reason_parts),
        )

    return RoutingDecision(
        model_override=config.AZURE_OPENAI_CHAT_FAST_DEPLOYMENT, tier="fast", reason="question judged simple"
    )
