"""
rag_pipeline.py
----------------
Orchestrates the full pipeline, end to end.

  INGESTION
    load documents (3 tracks: Document Intelligence, structured, visual)
    -> incremental-ingestion skip of unchanged files (inside document_loader.py)
    -> chunk -> write chunks.jsonl -> embed (Azure OpenAI) -> store (Azure AI Search)

  QUERY
    1. Input guardrail
    2. Query rewriting w/ history
    3. Embed the (rewritten) question (Azure OpenAI)
    4. Retrieve candidates w/ ACL filter + semantic ranking (Azure AI Search — this
       one call does what used to be two separate steps: retrieval AND reranking)
    5. Select final context (dedup + token budget)
    6. Build the prompt
    7. Route to a model tier (Azure OpenAI deployment)
    8. Generate the answer
    9. Output guardrail

Note there's one fewer numbered step than the local-first version: Azure AI
Search's semantic ranker folds "retrieve" and "rerank" into a single call
(src/vector_store.py), so there's no separate reranking step to orchestrate
here anymore.
"""

import json
import os

from tqdm import tqdm

import config
from src.document_loader import load_documents
from src.chunker import chunk_documents
from src.embedder import embed_texts, embed_single_text
from src.vector_store import VectorStore, get_vector_store
from src.llm_client import complete
from src.metadata_filter import build_where_clause
from src.query_processor import contextualize_query, ChatTurn
from src.context_selector import select_context
from src.prompt_builder import build_prompt
from src.llm_router import route
from src.guardrails import check_input, check_output
from src.logging_setup import get_logger

logger = get_logger()


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------

def _write_chunks_jsonl(chunks, output_path: str) -> None:
    """Persist every chunk (text + provenance, no embeddings) as one JSON object per line, for inspection."""
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(
                json.dumps(
                    {
                        "chunk_id": c.chunk_id,
                        "source_filename": c.source_filename,
                        "text": c.text,
                        "page_number": c.page_number,
                        "section_title": c.section_title,
                        "content_type": c.content_type,
                        "image_path": c.image_path,
                        "document_type": c.document_type,
                        "data_source": c.data_source,
                        "allowed_roles": c.allowed_roles,
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )


def run_ingestion(raw_docs_dir: str = config.RAW_DOCS_DIR) -> None:
    """
    Full ingestion pipeline. Incremental-ingestion filtering (skipping
    files unchanged since the last run) happens INSIDE load_documents() —
    see src/document_loader.py and src/incremental_ingestion.py — so by
    the time documents come back here, they're already just the new/changed
    ones that actually need (potentially costly) processing.
    """
    logger.info(f"Loading documents from '{raw_docs_dir}' (Document Intelligence + structured + vision tracks) ...")
    documents = load_documents(raw_docs_dir)
    logger.info(f"Loaded {len(documents)} new/changed document(s).")

    if not documents:
        logger.info("No new or changed documents to ingest. Nothing to do.")
        return

    logger.info("Chunking documents ...")
    chunks = chunk_documents(documents)
    logger.info(f"Created {len(chunks)} chunk(s).")

    chunks_jsonl_path = os.path.join(config.PROCESSED_DIR, "chunks.jsonl")
    _write_chunks_jsonl(chunks, chunks_jsonl_path)
    logger.info(f"Wrote chunk artifact to {chunks_jsonl_path}.")

    logger.info("Generating embeddings via Azure OpenAI (batched) ...")
    chunk_texts = [c.text for c in chunks]
    embeddings = embed_texts(chunk_texts)

    logger.info("Storing chunks in Azure AI Search ...")
    vector_store = VectorStore()

    ids = [c.chunk_id for c in chunks]
    metadatas = [
        {
            "source_filename": c.source_filename,
            "page_number": c.page_number,
            "section_title": c.section_title,
            "content_type": c.content_type,
            "image_path": c.image_path,
            "document_type": c.document_type,
            "data_source": c.data_source,
            "allowed_roles": c.allowed_roles,
        }
        for c in chunks
    ]

    batch_size = 500
    for start in tqdm(range(0, len(chunks), batch_size), desc="Indexing batches"):
        end = start + batch_size
        vector_store.add(
            ids=ids[start:end],
            embeddings=embeddings[start:end],
            documents=chunk_texts[start:end],
            metadatas=metadatas[start:end],
        )

    logger.info(f"Done. Index now contains {vector_store.count()} chunk(s).")


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------

def run_query(
    question: str,
    history: list[ChatTurn] | None = None,
    user_roles: list[str] | None = None,
    document_type: str | None = None,
    data_source: str | None = None,
) -> dict:
    """
    Full query pipeline. See module docstring for the step list — one
    fewer explicit step than the local-first version since Azure AI
    Search's semantic ranker folds retrieval + reranking into one call.
    """
    input_check = check_input(question)
    if not input_check.passed:
        logger.info(f"Input guardrail blocked a question: {input_check.reason}")
        return {"question": question, "answer": None, "sources": [], "blocked": True, "block_reason": input_check.reason}

    vector_store = get_vector_store()
    if vector_store.count() == 0:
        raise RuntimeError("The search index is empty. Run ingestion first: python -m scripts.ingest")

    rewritten_question = contextualize_query(question, history)

    logger.info("Embedding the question ...")
    question_embedding = embed_single_text(rewritten_question)

    where_clause = build_where_clause(user_roles=user_roles, document_type=document_type, data_source=data_source)

    # top_k = INITIAL_RETRIEVAL_K gives Azure AI Search's semantic ranker a
    # wider pool of vector-search candidates to rerank within, before we
    # narrow to RERANK_TOP_N for context selection below.
    logger.info(f"Retrieving up to {config.INITIAL_RETRIEVAL_K} candidate chunk(s) ...")
    candidates = vector_store.query(question_embedding, top_k=config.INITIAL_RETRIEVAL_K, where=where_clause)

    if not candidates:
        return {
            "question": question,
            "rewritten_question": rewritten_question,
            "answer": "I couldn't find any relevant information to answer this question "
                      "(no matching documents — this may be due to access restrictions "
                      "or no ingested content matching your filters).",
            "sources": [],
            "blocked": False,
        }

    ranked = candidates[: config.RERANK_TOP_N]  # already sorted best-first by vector_store.query()

    selected_chunks = select_context(ranked)

    history_text = None
    if history:
        recent = history[-config.QUERY_REWRITE_HISTORY_TURNS:]
        history_text = "\n".join(f"User: {t.question}\nAssistant: {t.answer}" for t in recent)

    prompt_result = build_prompt(rewritten_question, selected_chunks, history_text=history_text)

    routing_decision = route(rewritten_question, num_context_chunks=len(selected_chunks))

    logger.info(f"Generating answer (tier: {routing_decision.tier}) ...")
    answer = complete(prompt_result.prompt, model_override=routing_decision.model_override)

    selected_texts = [c.text for c in selected_chunks]
    output_check = check_output(answer, selected_texts)
    if not output_check.passed:
        logger.warning(f"Output guardrail flagged low grounding: {output_check.reason}")

    sources = [
        {
            "chunk_id": c.chunk_id,
            "source_filename": c.metadata.get("source_filename", "unknown"),
            "page_number": c.metadata.get("page_number"),
            "section_title": c.metadata.get("section_title"),
            "content_type": c.metadata.get("content_type"),
            "image_path": c.metadata.get("image_path"),
            "document_type": c.metadata.get("document_type"),
            "data_source": c.metadata.get("data_source"),
            "chunk_preview": c.text[:200] + ("..." if len(c.text) > 200 else ""),
        }
        for c in selected_chunks
    ]

    return {
        "question": question,
        "rewritten_question": rewritten_question if rewritten_question != question else None,
        "answer": answer,
        "sources": sources,
        "blocked": False,
        "routing": {"tier": routing_decision.tier, "reason": routing_decision.reason},
        "grounding_warning": None if output_check.passed else output_check.reason,
    }
