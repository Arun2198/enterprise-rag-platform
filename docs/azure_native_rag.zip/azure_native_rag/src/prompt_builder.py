"""
prompt_builder.py
------------------
Assembles the final prompt sent to the LLM. Logic is unchanged from the
local-first version, with one addition: a chunk whose `content_type` is
"visual" (i.e., its text is a vision-generated caption, not directly
authored prose) is labeled differently in its citation — "[Source: X,
described from an image]" instead of "page N" — so the model (and
ultimately the user) knows that piece of context came from an AI's
interpretation of a picture, not a verbatim read of text. That distinction
matters given the known limitation that analog gauge readings especially
can be approximate.
"""

from dataclasses import dataclass

_SYSTEM_INSTRUCTIONS = (
    "You are a helpful assistant answering questions using ONLY the context "
    "provided below. Follow these rules strictly:\n"
    "1. If the answer isn't contained in the context, say you don't have "
    "enough information — do not make something up.\n"
    "2. When you use a fact from the context, cite its source using the "
    "[Source: <filename>, ...] format shown before each context block.\n"
    "3. If a piece of context is marked \"described from an image\", treat "
    "it as an AI-generated description of a picture, not a verbatim quote — "
    "say so if the user's question hinges on an exact reading (e.g. a gauge "
    "value), since image-derived readings can be approximate.\n"
    "4. Be concise and directly answer the question first, then add "
    "supporting detail if useful."
)


@dataclass
class PromptResult:
    prompt: str
    chunk_ids_used: list[str]


def build_prompt(question: str, selected_chunks: list, history_text: str | None = None) -> PromptResult:
    context_blocks = []
    chunk_ids_used = []

    for chunk in selected_chunks:
        source_name = chunk.metadata.get("source_filename", "unknown_source")
        location = source_name

        if chunk.metadata.get("content_type") == "visual":
            location += ", described from an image"
        elif chunk.metadata.get("page_number"):
            location += f", page {chunk.metadata['page_number']}"
        elif chunk.metadata.get("section_title"):
            location += f", section \"{chunk.metadata['section_title']}\""

        context_blocks.append(f"[Source: {location}]\n{chunk.text}")
        chunk_ids_used.append(chunk.chunk_id)

    context_section = "\n\n---\n\n".join(context_blocks) if context_blocks else "(no context retrieved)"

    sections = [_SYSTEM_INSTRUCTIONS]
    if history_text:
        sections.append(f"Recent conversation:\n{history_text}")
    sections.append(f"CONTEXT:\n{context_section}")
    sections.append(f"QUESTION:\n{question}")
    sections.append("ANSWER:")

    return PromptResult(prompt="\n\n".join(sections), chunk_ids_used=chunk_ids_used)
