"""
auth.py
-------
Simple shared-secret API key check for the public endpoint — the
deliberately-simple choice from the design discussion, instead of Azure
API Management (which adds real value once there are multiple APIs or
external partners, but is unnecessary ceremony at this scale — see the
Consumption tier cost discussion for when it's worth revisiting).

Every request to a protected route must include a header:
    X-API-Key: <the value of config.API_KEY>

This is intentionally basic: one shared key for everyone who has it, not
per-user identity (that's the Entra ID upgrade path, deliberately deferred
until there's an actual need to tie access to individual users rather than
"anyone with the key").
"""

from fastapi import Header, HTTPException

import config


def require_api_key(x_api_key: str = Header(default=None)) -> None:
    """
    FastAPI dependency — add `dependencies=[Depends(require_api_key)]` to
    any route that should be protected. Raises 401 if the key is missing
    or wrong, which FastAPI turns into a proper HTTP error response.
    """
    if not config.API_KEY:
        # No key configured at all (e.g. local dev without .env fully set
        # up) — fail OPEN locally rather than locking developers out of
        # their own machine, but this should never be the case once deployed.
        return

    if x_api_key != config.API_KEY:
        raise HTTPException(status_code=401, detail="Missing or invalid X-API-Key header.")
