"""
evaluation.py
--------------
Retrieval metrics (recall/precision@k) + LLM-as-judge generation scoring
(relevance/faithfulness) — unchanged in logic from the local-first
version. The judge calls route through llm_client.complete(), which is
now Azure OpenAI only, so judge scoring now genuinely costs a small amount
per evaluation run (previously free against a local Ollama model) — worth
knowing before running a large evaluation set, though the amounts involved
are small relative to Document Intelligence/vision costs.
"""

import json
import os

import config
from src.llm_client import complete
from src.logging_setup import get_logger

logger = get_logger()

_JUDGE_PROMPT_TEMPLATE = """You are grading a RAG system's answer.

Question: {question}

Retrieved context:
{context}

Generated answer:
{answer}

Score the answer from 1 (worst) to 5 (best) on two dimensions and return ONLY
valid JSON, no other text:
{{
  "relevance": <int 1-5, does the answer address the question?>,
  "faithfulness": <int 1-5, is the answer fully supported by the retrieved context, with no invented facts?>,
  "explanation": "<one short sentence>"
}}
"""


def retrieval_recall_at_k(retrieved_sources: list[str], relevant_sources: list[str]) -> float:
    if not relevant_sources:
        return 0.0
    hits = len(set(retrieved_sources) & set(relevant_sources))
    return hits / len(set(relevant_sources))


def retrieval_precision_at_k(retrieved_sources: list[str], relevant_sources: list[str]) -> float:
    if not retrieved_sources:
        return 0.0
    hits = len(set(retrieved_sources) & set(relevant_sources))
    return hits / len(set(retrieved_sources))


def judge_answer(question: str, context: str, answer: str) -> dict:
    prompt = _JUDGE_PROMPT_TEMPLATE.format(question=question, context=context, answer=answer)
    raw = complete(prompt).strip()

    if raw.startswith("```"):
        raw = raw.strip("`").removeprefix("json").strip()

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning(f"Judge returned unparseable output: {raw[:200]}")
        return {"relevance": None, "faithfulness": None, "explanation": f"Unparseable judge output: {raw[:200]}"}


def load_test_set(path: str) -> list[dict]:
    cases = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                cases.append(json.loads(line))
    return cases


def run_evaluation(test_set_path: str = None, output_report_path: str = None) -> dict:
    from src.rag_pipeline import run_query  # imported here to avoid a circular import

    test_set_path = test_set_path or config.EVAL_TEST_SET_PATH
    output_report_path = output_report_path or config.EVAL_REPORT_PATH

    test_cases = load_test_set(test_set_path)
    logger.info(f"Loaded {len(test_cases)} evaluation question(s) from {test_set_path}")

    per_question_results = []
    for case in test_cases:
        question = case["question"]
        relevant_sources = case.get("relevant_source_files", [])

        result = run_query(question)
        retrieved_sources = [s["source_filename"] for s in result.get("sources", [])]

        row = {
            "question": question,
            "answer": result.get("answer"),
            "retrieved_sources": retrieved_sources,
            "relevant_sources": relevant_sources,
            "recall_at_k": retrieval_recall_at_k(retrieved_sources, relevant_sources),
            "precision_at_k": retrieval_precision_at_k(retrieved_sources, relevant_sources),
        }

        if config.EVAL_LLM_JUDGE_ENABLED and result.get("answer"):
            context_text = "\n".join(
                f"{s['source_filename']}" + (f" (page {s['page_number']})" if s.get("page_number") else "")
                for s in result.get("sources", [])
            )
            row.update(judge_answer(question, context_text, result["answer"]))

        per_question_results.append(row)
        logger.info(f"  Evaluated: {question[:60]}...")

    def _mean(values):
        values = [v for v in values if v is not None]
        return sum(values) / len(values) if values else None

    summary = {
        "num_questions": len(per_question_results),
        "avg_recall_at_k": _mean([r["recall_at_k"] for r in per_question_results]),
        "avg_precision_at_k": _mean([r["precision_at_k"] for r in per_question_results]),
    }
    if config.EVAL_LLM_JUDGE_ENABLED:
        summary["avg_relevance"] = _mean([r.get("relevance") for r in per_question_results])
        summary["avg_faithfulness"] = _mean([r.get("faithfulness") for r in per_question_results])

    report = {"summary": summary, "results": per_question_results}

    os.makedirs(os.path.dirname(output_report_path) or ".", exist_ok=True)
    with open(output_report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    logger.info(f"Evaluation report written to {output_report_path}")
    logger.info(f"Summary: {summary}")
    return report
