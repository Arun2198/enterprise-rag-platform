"""
logging_setup.py
-----------------
Central logging configuration. Every library module (src/*.py) logs
through this instead of scattering print() calls around.

Two modes, chosen automatically:
  - APPLICATIONINSIGHTS_CONNECTION_STRING is set (true once deployed) ->
    logs are also sent to Azure Monitor / Application Insights, so you can
    query and alert on them from the Azure Portal without shell access to
    the container.
  - Not set (typical local dev) -> logs go to the console and a local
    logs/app.log file only, exactly like the local-first version of this
    project.

Either way, console output always happens too — Container Apps captures
stdout/stderr as log output automatically, so you're never fully blind
even if the Application Insights wiring has an issue.
"""

import logging
import os
import sys

import config

_logger: logging.Logger | None = None


def get_logger() -> logging.Logger:
    global _logger
    if _logger is not None:
        return _logger

    logger = logging.getLogger("azure_native_rag")
    logger.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))

    if not logger.handlers:
        formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")

        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        log_dir = os.path.dirname(config.LOG_FILE) or "."
        os.makedirs(log_dir, exist_ok=True)
        file_handler = logging.FileHandler(config.LOG_FILE)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        if config.APPLICATIONINSIGHTS_CONNECTION_STRING:
            try:
                # Imported only when actually configured, so local dev
                # without Application Insights doesn't need this package
                # installed working correctly to run at all.
                from azure.monitor.opentelemetry import configure_azure_monitor

                configure_azure_monitor(
                    connection_string=config.APPLICATIONINSIGHTS_CONNECTION_STRING,
                    logger_name="azure_native_rag",
                )
                logger.info("Application Insights logging enabled.")
            except Exception as exc:
                logger.warning(f"Could not initialize Application Insights logging: {exc}")

    _logger = logger
    return _logger
