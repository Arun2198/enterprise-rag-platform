"""
document_loader.py
-------------------
Orchestrates all three ingestion tracks discussed in the design
conversation into one unified interface. This is the file that decides,
per input file, which track(s) it needs to go through:

  TRACK 1 (text/tables)   .pdf, .docx, .html/.htm  -> document_intelligence_loader.py
  TRACK 2 (structured)     .xlsx, .csv               -> structured_loader.py
  TRACK 3 (visual)         embedded images in PDFs,   -> image_extractor.py + vision_captioner.py
                            .dwg (converted first)       (dwg_converter.py handles the conversion)

A PDF typically runs through BOTH Track 1 (its text/tables) AND Track 3
(any embedded diagrams/photos above the size threshold) — these aren't
alternatives, they're complementary passes over the same file, which is
exactly the "three tracks, not one" design from the earlier discussion.

Every extracted piece becomes a Section — {text, page_number,
section_title, content_type, image_path} — so a chunk built from a vision
caption carries the same provenance shape as a chunk built from Document
Intelligence text, and both flow through the rest of the pipeline
identically from here on.
"""

import json
import os
import re
from dataclasses import dataclass, field

import config
from src.logging_setup import get_logger
from src.document_intelligence_loader import load_with_document_intelligence
from src.structured_loader import load_xlsx, load_csv
from src.image_extractor import extract_images
from src.vision_captioner import caption_image
from src.dwg_converter import convert_dwg_to_pdf
from src.incremental_ingestion import filter_changed_files, save_manifest

logger = get_logger()

EXTRACTED_IMAGES_DIR = os.path.join(config.PROCESSED_DIR, "extracted_images")
DWG_CONVERTED_DIR = os.path.join(config.PROCESSED_DIR, "dwg_converted")


@dataclass
class Section:
    text: str
    page_number: int | None = None
    section_title: str | None = None
    content_type: str = "text"          # "text" (from Document Intelligence/structured data) or "visual" (from vision captioning)
    image_path: str | None = None        # set for content_type="visual", so the UI can show the original image


@dataclass
class LoadedDocument:
    source_filename: str
    sections: list[Section]
    document_type: str = "general"
    data_source: str = "local_upload"
    allowed_roles: list = field(default_factory=lambda: ["admin", "employee"])


# ---------------------------------------------------------------------------
# Text cleanup (unchanged from the local-first version)
# ---------------------------------------------------------------------------

def clean_text(text: str, remove_patterns: list[str] | None = None) -> str:
    for pattern in remove_patterns or []:
        text = re.sub(pattern, "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


# ---------------------------------------------------------------------------
# Metadata manifest (unchanged from the local-first version)
# ---------------------------------------------------------------------------

def _load_metadata_manifest(raw_docs_dir: str) -> dict:
    manifest_path = os.path.join(os.path.dirname(raw_docs_dir.rstrip("/")), "metadata_manifest.json")
    if not os.path.exists(manifest_path):
        manifest_path = os.path.join(raw_docs_dir, "..", "metadata_manifest.json")
    if not os.path.exists(manifest_path):
        return {"defaults": {}, "overrides": {}}
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    return {"defaults": manifest.get("defaults", {}), "overrides": manifest.get("overrides", {})}


def _resolve_metadata(filename: str, manifest: dict) -> dict:
    resolved = dict(manifest.get("defaults", {}))
    resolved.update(manifest.get("overrides", {}).get(filename, {}))
    return resolved


# ---------------------------------------------------------------------------
# Per-format loading
# ---------------------------------------------------------------------------

def _load_visual_sections_from_pdf(pdf_path: str) -> list[Section]:
    """
    Track 3 for one PDF: extract embedded images above the size threshold
    and caption each one, producing one Section per captioned image.
    Skipped entirely (returns []) if ENABLE_VISION_CAPTIONING is false, or
    if no images meet the size threshold — most text-only PDF pages will
    produce nothing here, which is expected and fine.
    """
    if not config.ENABLE_VISION_CAPTIONING:
        return []

    images = extract_images(pdf_path, EXTRACTED_IMAGES_DIR)
    sections = []
    for img in images:
        caption = caption_image(img["image_path"])
        if caption:
            sections.append(
                Section(
                    text=caption,
                    page_number=img["page_number"],
                    section_title="Embedded diagram/image",
                    content_type="visual",
                    image_path=img["image_path"],
                )
            )
    return sections


def _load_pdf(path: str) -> list[Section]:
    """PDF: Track 1 (Document Intelligence) + Track 3 (embedded image captioning) combined."""
    text_pages = load_with_document_intelligence(path)
    text_sections = [
        Section(text=p["text"], page_number=p["page_number"], section_title=p["section_title"], content_type="text")
        for p in text_pages
    ]
    visual_sections = _load_visual_sections_from_pdf(path)
    return text_sections + visual_sections


def _load_docx_or_html(path: str) -> list[Section]:
    """DOCX/HTML: Track 1 only (Document Intelligence) — no embedded-image extraction path built for these formats yet, see README known gaps."""
    text_pages = load_with_document_intelligence(path)
    return [
        Section(text=p["text"], page_number=p["page_number"], section_title=p["section_title"], content_type="text")
        for p in text_pages
    ]


def _load_xlsx(path: str) -> list[Section]:
    pages = load_xlsx(path)
    return [Section(text=p["text"], page_number=p["page_number"], section_title=p["section_title"]) for p in pages]


def _load_csv(path: str) -> list[Section]:
    pages = load_csv(path)
    return [Section(text=p["text"], page_number=p["page_number"], section_title=p["section_title"]) for p in pages]


def _load_dwg(path: str) -> list[Section]:
    """
    DWG: convert to PDF first (dwg_converter.py), then run the SAME PDF
    pipeline as any other PDF (Track 1 for title-block/annotation text,
    Track 3 for the drawing content itself as a captioned image). If
    conversion isn't possible (converter not installed), returns []
    with a warning already logged by dwg_converter.
    """
    pdf_path = convert_dwg_to_pdf(path, DWG_CONVERTED_DIR)
    if not pdf_path:
        return []
    return _load_pdf(pdf_path)


_LOADERS = {
    ".pdf": _load_pdf,
    ".docx": _load_docx_or_html,
    ".html": _load_docx_or_html,
    ".htm": _load_docx_or_html,
    ".xlsx": _load_xlsx,
    ".csv": _load_csv,
    ".dwg": _load_dwg,
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def load_documents(raw_docs_dir: str) -> list[LoadedDocument]:
    """
    Walk `raw_docs_dir` recursively, skip files unchanged since the last
    ingestion run (incremental_ingestion.py), and load every remaining
    supported file through the appropriate track(s) above. The ingestion
    manifest is saved at the END of this function, only after every file
    was processed — so a mid-run failure doesn't mark files as "done" that
    weren't actually successfully ingested.
    """
    manifest_meta = _load_metadata_manifest(raw_docs_dir)

    all_paths = []
    for root, _dirs, files in os.walk(raw_docs_dir):
        for filename in files:
            if os.path.splitext(filename)[1].lower() in _LOADERS:
                all_paths.append(os.path.join(root, filename))

    changed_paths, new_ingestion_manifest = filter_changed_files(all_paths)

    loaded_documents = []
    for full_path in changed_paths:
        filename = os.path.basename(full_path)
        extension = os.path.splitext(filename)[1].lower()
        loader_fn = _LOADERS[extension]

        try:
            sections = loader_fn(full_path)
        except Exception as exc:
            logger.error(f"Failed to load {filename}: {exc}")
            continue

        for section in sections:
            section.text = clean_text(section.text, config.CLEANING_REMOVE_PATTERNS)
        sections = [s for s in sections if s.text.strip()]

        if not sections:
            logger.warning(f"No extractable content found in {filename}")
            continue

        metadata = _resolve_metadata(filename, manifest_meta)
        loaded_documents.append(
            LoadedDocument(
                source_filename=filename,
                sections=sections,
                document_type=metadata.get("document_type", "general"),
                data_source=metadata.get("data_source", "local_upload"),
                allowed_roles=metadata.get("allowed_roles", ["admin", "employee"]),
            )
        )

    save_manifest(new_ingestion_manifest)
    return loaded_documents
