"""
chunker.py
----------
Splits each document's sections into overlapping chunks using LangChain's
RecursiveCharacterTextSplitter — unchanged in approach from the local-first
version (paragraph/sentence-boundary-aware splitting, not raw character
counts).

One addition for the Azure-native version: chunks now also carry
`content_type` ("text" or "visual") and `image_path`. A "visual" chunk's
text IS a vision-generated caption, not directly-authored prose — this
distinction is preserved so the prompt builder can cite it differently
("described from an image" vs. a normal page reference) and so a UI can
show the original image alongside the answer.

Visual-content sections are typically short (a single image caption) and
usually don't need splitting further — the splitter just passes them
through as one chunk in that common case, which is exactly what "recursive
splitting" does naturally when the text is already under chunk_size.
"""

import uuid
from dataclasses import dataclass, field

from langchain_text_splitters import RecursiveCharacterTextSplitter

import config


@dataclass
class Chunk:
    chunk_id: str
    source_filename: str
    text: str
    page_number: int | None = None
    section_title: str | None = None
    content_type: str = "text"
    image_path: str | None = None
    document_type: str = "general"
    data_source: str = "local_upload"
    allowed_roles: list = field(default_factory=lambda: ["admin", "employee"])


def _build_splitter(chunk_size: int, chunk_overlap: int) -> RecursiveCharacterTextSplitter:
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )


def chunk_documents(loaded_documents) -> list["Chunk"]:
    splitter = _build_splitter(config.CHUNK_SIZE_CHARS, config.CHUNK_OVERLAP_CHARS)
    all_chunks: list[Chunk] = []

    for document in loaded_documents:
        for section in document.sections:
            pieces = splitter.split_text(section.text)

            for piece in pieces:
                piece = piece.strip()
                if len(piece) < config.MIN_CHUNK_LENGTH_CHARS:
                    continue

                all_chunks.append(
                    Chunk(
                        chunk_id=str(uuid.uuid4()),
                        source_filename=document.source_filename,
                        text=piece,
                        page_number=section.page_number,
                        section_title=section.section_title,
                        content_type=section.content_type,
                        image_path=section.image_path,
                        document_type=document.document_type,
                        data_source=document.data_source,
                        allowed_roles=document.allowed_roles,
                    )
                )

    return all_chunks
