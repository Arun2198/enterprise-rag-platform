"""
document_intelligence_loader.py
--------------------------------
Extracts text, tables, and page/section provenance from PDF, DOCX, and
HTML files using Azure AI Document Intelligence's **Layout** model —
the model chosen specifically because it preserves table structure and
page headings, not just raw OCR text (that's what the "Read" model would
give you, and it would lose your inspection tables' structure).

This is the "text track" of the three-track ingestion design:
  1. TEXT/TABLE TRACK (this file)      -> Document Intelligence
  2. STRUCTURED DATA TRACK             -> structured_loader.py (XLSX/CSV)
  3. VISUAL CONTENT TRACK              -> image_extractor.py + vision_captioner.py

Handwriting: the Layout model's underlying OCR also detects handwritten
text (this is a genuine strength of Document Intelligence), so scanned
handwritten inspection report pages come through here too — just expect
lower reliability than typed text, especially on messy handwriting.

Output shape: one Section per PAGE, matching the local-first version's
provenance model, so a citation can say "report.pdf, page 4". Any table
found on a page is rendered as a simple markdown table and appended to
that page's text, so table content is fully searchable.
"""

import os

from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
from azure.core.credentials import AzureKeyCredential

import config
from src.logging_setup import get_logger

logger = get_logger()

_client: DocumentIntelligenceClient | None = None


def _get_client() -> DocumentIntelligenceClient:
    global _client
    if _client is None:
        if not config.DOCUMENT_INTELLIGENCE_ENDPOINT or not config.DOCUMENT_INTELLIGENCE_KEY:
            raise ValueError(
                "DOCUMENT_INTELLIGENCE_ENDPOINT / DOCUMENT_INTELLIGENCE_KEY are not set. "
                "Fill these in after creating the Document Intelligence resource — see README Step 3."
            )
        _client = DocumentIntelligenceClient(
            endpoint=config.DOCUMENT_INTELLIGENCE_ENDPOINT,
            credential=AzureKeyCredential(config.DOCUMENT_INTELLIGENCE_KEY),
        )
    return _client


def _table_to_markdown(table) -> str:
    """
    Render one Document Intelligence table object as a simple markdown
    table string, so it reads naturally as text in a chunk (and therefore
    embeds and retrieves sensibly) instead of staying as structured JSON
    that a text embedding model has no good way to represent.
    """
    row_count = table.row_count
    col_count = table.column_count

    # Build a grid, then fill in cell content by (row, column) index.
    grid = [["" for _ in range(col_count)] for _ in range(row_count)]
    for cell in table.cells:
        if cell.row_index < row_count and cell.column_index < col_count:
            grid[cell.row_index][cell.column_index] = (cell.content or "").replace("\n", " ").strip()

    lines = []
    for i, row in enumerate(grid):
        lines.append("| " + " | ".join(row) + " |")
        if i == 0:  # markdown header separator after the first row
            lines.append("| " + " | ".join(["---"] * col_count) + " |")
    return "\n".join(lines)


def load_with_document_intelligence(path: str) -> list[dict]:
    """
    Analyze one PDF/DOCX/HTML file with Document Intelligence's Layout
    model and return a list of page dicts:
        {"page_number": int, "text": str, "section_title": str | None}

    Returns an empty list (with a logged error) if analysis fails for this
    specific file, rather than raising — one bad file shouldn't abort
    ingestion of the other 499MB.
    """
    client = _get_client()
    filename = os.path.basename(path)

    try:
        with open(path, "rb") as f:
            poller = client.begin_analyze_document(
                "prebuilt-layout",
                AnalyzeDocumentRequest(bytes_source=f.read()),
            )
        result = poller.result()
    except Exception as exc:
        logger.error(f"Document Intelligence failed on {filename}: {exc}")
        return []

    # Group paragraphs by the page they appear on, tracking any paragraph
    # tagged with a heading-like role as that page's section title.
    pages_text: dict[int, list[str]] = {}
    pages_title: dict[int, str] = {}

    for paragraph in result.paragraphs or []:
        if not paragraph.bounding_regions:
            continue
        page_number = paragraph.bounding_regions[0].page_number
        pages_text.setdefault(page_number, []).append(paragraph.content)

        if paragraph.role in ("title", "sectionHeading") and page_number not in pages_title:
            pages_title[page_number] = paragraph.content

    # Attach each table's markdown rendering to the page(s) it appears on.
    for table in result.tables or []:
        if not table.bounding_regions:
            continue
        page_number = table.bounding_regions[0].page_number
        pages_text.setdefault(page_number, []).append(_table_to_markdown(table))

    pages_output = []
    for page in result.pages or []:
        page_number = page.page_number
        text = "\n\n".join(pages_text.get(page_number, []))
        if text.strip():
            pages_output.append(
                {
                    "page_number": page_number,
                    "text": text,
                    "section_title": pages_title.get(page_number),
                }
            )

    logger.info(f"Document Intelligence extracted {len(pages_output)} page(s) from {filename}.")
    return pages_output
