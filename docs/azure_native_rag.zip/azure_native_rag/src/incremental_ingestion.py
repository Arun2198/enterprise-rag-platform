"""
incremental_ingestion.py
-------------------------
Tracks a content hash (SHA-256) per source file across ingestion runs, so
re-running ingestion doesn't re-pay for Document Intelligence parsing and
vision captioning on files that haven't changed since the last run.

This matters specifically because you're now on Azure: unlike the local-
first version (where re-parsing a file with PyMuPDF was free), every
Document Intelligence page and every vision-captioned image now has a
real, per-use cost. Re-ingesting your whole 500MB corpus on every run
because you added three new files would be a genuinely avoidable expense.

The manifest is a simple JSON file: {filename: sha256_hash}. On each
ingestion run:
  1. Compute the current hash of every file in data/raw_docs/.
  2. Compare against the manifest from the last run.
  3. Only files that are new or whose hash changed get (re)processed.
  4. The manifest is rewritten at the end of a successful run.

Disable with ENABLE_INCREMENTAL_INGESTION=false in .env if you ever want
to force a full re-ingestion (e.g. after changing chunking settings, since
a changed chunk size affects every file even if the files themselves
didn't change — the hash check alone can't know that).
"""

import hashlib
import json
import os

import config
from src.logging_setup import get_logger

logger = get_logger()


def _hash_file(path: str) -> str:
    """SHA-256 hash of a file's contents, computed in chunks so large files (CAD drawings, big PDFs) don't need to be fully loaded into memory at once."""
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            hasher.update(block)
    return hasher.hexdigest()


def load_manifest() -> dict:
    """Load the {filename: hash} manifest from the last ingestion run, or an empty dict if none exists yet."""
    if not os.path.exists(config.INGESTION_MANIFEST_PATH):
        return {}
    with open(config.INGESTION_MANIFEST_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_manifest(manifest: dict) -> None:
    os.makedirs(os.path.dirname(config.INGESTION_MANIFEST_PATH) or ".", exist_ok=True)
    with open(config.INGESTION_MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)


def filter_changed_files(all_file_paths: list[str]) -> tuple[list[str], dict]:
    """
    Given every file path under data/raw_docs/, return:
      - the subset that is new or changed since the last ingestion run
        (these are the ones that actually need to go through Document
        Intelligence / vision captioning / embedding this run)
      - the updated manifest (old entries + new hashes for changed files),
        to be saved via save_manifest() once ingestion succeeds

    If ENABLE_INCREMENTAL_INGESTION is false, every file is treated as
    changed (i.e. a full re-ingestion), and the manifest is still computed
    and returned so it's ready to save if you re-enable incremental mode later.
    """
    old_manifest = load_manifest()
    new_manifest = dict(old_manifest)
    changed_files = []

    for path in all_file_paths:
        current_hash = _hash_file(path)
        # Use a path relative to the raw docs root as the manifest key, so
        # the manifest doesn't break if the project is checked out to a
        # different absolute path on another machine.
        key = os.path.relpath(path, config.RAW_DOCS_DIR)

        is_changed = not config.ENABLE_INCREMENTAL_INGESTION or old_manifest.get(key) != current_hash
        if is_changed:
            changed_files.append(path)

        new_manifest[key] = current_hash

    skipped_count = len(all_file_paths) - len(changed_files)
    if skipped_count > 0:
        logger.info(f"Incremental ingestion: skipping {skipped_count} unchanged file(s).")

    return changed_files, new_manifest
