"""
context_selector.py
--------------------
Unchanged in approach from the local-first version — this logic has
nothing to do with which vector store or cloud you're using, so it ported
over as-is:

  1. Deduplication — near-identical chunks (common with overlapping chunk
     windows) are collapsed, keeping the higher-ranked copy.
  2. Token budgeting — chunks are added to the final context in rank order
     until the next one would exceed CONTEXT_TOKEN_BUDGET, then selection
     stops.

Operates on VectorStore.RetrievedChunk objects (already sorted best-first
by vector_store.query(), semantically reranked if enabled).
"""

from dataclasses import dataclass
from difflib import SequenceMatcher

import config


@dataclass
class SelectedChunk:
    chunk_id: str
    text: str
    metadata: dict


def _estimate_tokens(text: str) -> int:
    """~4 characters per token — a standard rule of thumb for English text, avoids a tokenizer dependency."""
    return max(1, len(text) // 4)


def _is_near_duplicate(text_a: str, text_b: str, threshold: float) -> bool:
    return SequenceMatcher(None, text_a, text_b).ratio() >= threshold


def deduplicate(candidates: list) -> list:
    kept = []
    for candidate in candidates:
        is_duplicate = any(
            _is_near_duplicate(candidate.text, kept_chunk.text, config.DEDUP_SIMILARITY_THRESHOLD)
            for kept_chunk in kept
        )
        if not is_duplicate:
            kept.append(candidate)
    return kept


def select_context(candidates: list, token_budget: int = config.CONTEXT_TOKEN_BUDGET) -> list[SelectedChunk]:
    deduped = deduplicate(candidates)

    selected: list[SelectedChunk] = []
    running_token_count = 0

    for candidate in deduped:
        chunk_tokens = _estimate_tokens(candidate.text)
        if running_token_count + chunk_tokens > token_budget:
            break
        selected.append(SelectedChunk(chunk_id=candidate.chunk_id, text=candidate.text, metadata=candidate.metadata))
        running_token_count += chunk_tokens

    return selected
