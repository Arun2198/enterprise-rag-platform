"""
image_extractor.py
-------------------
Pulls embedded raster images (diagrams, drawings, photos) OUT of PDF
pages, so they can be sent to a vision model for captioning.

Important distinction from document_intelligence_loader.py: this module
extracts zero TEXT. Its only job is finding the image files hiding inside
a PDF. All text extraction (including any text visible ON those same
pages) still goes through Document Intelligence — the two tracks run
side by side on the same PDF, not instead of each other.

Uses PyMuPDF purely as an image-extraction utility (not for text, which
is why this is a legitimate use of a free library alongside a paid Azure
service — they're not competing for the same job).

Small/decorative images (logos, bullet icons, thin divider lines) are
filtered out by pixel area (config.MIN_IMAGE_PIXELS) BEFORE anything gets
sent to a vision model — this is the main cost control for the visual
track, since vision captioning is priced per image.
"""

import os

import fitz  # PyMuPDF

import config
from src.logging_setup import get_logger

logger = get_logger()


def extract_images(pdf_path: str, output_dir: str) -> list[dict]:
    """
    Extract every embedded image above the minimum size threshold from
    `pdf_path`, saving each as a PNG under `output_dir`, and return:
        [{"page_number": int, "image_path": str}, ...]

    Images smaller than config.MIN_IMAGE_PIXELS (width * height) are
    skipped entirely — these are almost always logos/icons/dividers, not
    diagrams or photos worth the cost of captioning.
    """
    filename = os.path.splitext(os.path.basename(pdf_path))[0]
    os.makedirs(output_dir, exist_ok=True)
    extracted = []

    try:
        doc = fitz.open(pdf_path)
    except Exception as exc:
        logger.error(f"Could not open {pdf_path} for image extraction: {exc}")
        return []

    with doc:
        for page_index, page in enumerate(doc):
            page_number = page_index + 1
            for image_index, img in enumerate(page.get_images(full=True)):
                xref = img[0]
                try:
                    base_image = doc.extract_image(xref)
                except Exception as exc:
                    logger.warning(f"Skipping unreadable image on {filename} page {page_number}: {exc}")
                    continue

                width, height = base_image.get("width", 0), base_image.get("height", 0)
                if width * height < config.MIN_IMAGE_PIXELS:
                    continue  # too small to be a meaningful diagram/photo — skip, saves captioning cost

                image_bytes = base_image["image"]
                extension = base_image.get("ext", "png")
                out_path = os.path.join(output_dir, f"{filename}_p{page_number}_i{image_index}.{extension}")
                with open(out_path, "wb") as f:
                    f.write(image_bytes)

                extracted.append({"page_number": page_number, "image_path": out_path})

    if extracted:
        logger.info(f"Extracted {len(extracted)} image(s) above size threshold from {filename}.")
    return extracted
