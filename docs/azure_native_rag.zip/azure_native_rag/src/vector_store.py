"""
vector_store.py
----------------
Wraps Azure AI Search behind the same small VectorStore interface the
local-first version used for ChromaDB — add() and query() — so the rest
of the pipeline (rag_pipeline.py) doesn't need to know or care which
vector store is behind it.

Two things are genuinely BETTER here than the ChromaDB version, worth
calling out:

1. RBAC/ACL filtering is more natural. ChromaDB's metadata store can't
   hold a list value, so the local-first version had to flatten
   `allowed_roles: ["admin"]` into separate boolean fields
   (`role_admin: true`, `role_employee: false`, ...) as a workaround.
   Azure AI Search natively supports a Collection(Edm.String) field, so
   `allowed_roles` is stored as an actual list and filtered directly with
   OData syntax (`allowed_roles/any(r: r eq 'admin')`) — no flattening
   hack needed. See metadata_filter.py.

2. Reranking is built in. The local-first version ran a self-hosted
   cross-encoder model (src/reranker.py) as a second pass after initial
   retrieval. Azure AI Search's **semantic ranker** does the equivalent
   job as a managed feature of the search call itself — one fewer
   component to run/manage/pay compute for. Enable/disable with
   ENABLE_SEMANTIC_RANKING in .env; requires a semantic configuration to
   be defined on the index (see infra/create_search_index.py).

The index itself is created once via infra/create_search_index.py, NOT by
this module — this module assumes the index already exists and just
reads/writes documents against it.
"""

from dataclasses import dataclass

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery

import config
from src.logging_setup import get_logger

logger = get_logger()


@dataclass
class RetrievedChunk:
    chunk_id: str
    text: str
    metadata: dict
    score: float


class VectorStore:
    def __init__(self):
        if not config.AZURE_SEARCH_ENDPOINT or not config.AZURE_SEARCH_API_KEY:
            raise ValueError(
                "AZURE_SEARCH_ENDPOINT / AZURE_SEARCH_API_KEY are not set. "
                "Fill these in after creating the Search resource — see README Step 4, "
                "and run infra/create_search_index.py once to create the index itself."
            )
        self._client = SearchClient(
            endpoint=config.AZURE_SEARCH_ENDPOINT,
            index_name=config.AZURE_SEARCH_INDEX_NAME,
            credential=AzureKeyCredential(config.AZURE_SEARCH_API_KEY),
        )

    def add(
        self,
        ids: list[str],
        embeddings: list[list[float]],
        documents: list[str],
        metadatas: list[dict],
    ) -> None:
        """
        Upload a batch of chunks. Each metadata dict is expected to carry
        the fields defined in the index schema (source_filename,
        page_number, section_title, content_type, image_path,
        document_type, data_source, allowed_roles) — see
        infra/create_search_index.py for the exact schema these must match.

        Uploads happen in batches of 1000, Azure AI Search's per-request
        document limit.
        """
        search_docs = []
        for chunk_id, embedding, text, metadata in zip(ids, embeddings, documents, metadatas):
            doc = {
                "id": chunk_id,
                "content": text,
                "content_vector": embedding,
                "source_filename": metadata.get("source_filename"),
                "section_title": metadata.get("section_title"),
                "content_type": metadata.get("content_type", "text"),
                "image_path": metadata.get("image_path"),
                "document_type": metadata.get("document_type", "general"),
                "data_source": metadata.get("data_source", "local_upload"),
                "allowed_roles": metadata.get("allowed_roles", []),
            }
            # page_number is legitimately absent for XLSX/CSV/visual-caption
            # chunks — omit the key entirely rather than sending null, since
            # Azure Search's Int32 fields are happiest simply not present.
            if metadata.get("page_number") is not None:
                doc["page_number"] = metadata["page_number"]

            search_docs.append(doc)

        batch_size = 1000
        for start in range(0, len(search_docs), batch_size):
            batch = search_docs[start : start + batch_size]
            result = self._client.upload_documents(documents=batch)
            failed = [r for r in result if not r.succeeded]
            if failed:
                logger.error(f"{len(failed)} document(s) failed to upload in this batch (see Search errors).")

    def query(self, query_embedding: list[float], top_k: int, where: str | None = None) -> list["RetrievedChunk"]:
        """
        Vector search (optionally filtered and semantically reranked),
        returning a flat list of RetrievedChunk objects, sorted best-first
        — a plain list, not Chroma's nested-list convention, since that
        convention was purely an artifact of Chroma's API and doesn't
        belong here.

        `where` is a pre-built OData filter string from metadata_filter.py.

        When ENABLE_SEMANTIC_RANKING is true, Azure AI Search's built-in
        semantic reranker runs as part of THIS call and the results come
        back already reranked — there's no separate reranking step
        elsewhere in the pipeline anymore (unlike the local-first
        version's self-hosted cross-encoder), because Azure AI Search does
        that job natively.
        """
        vector_query = VectorizedQuery(vector=query_embedding, k_nearest_neighbors=top_k, fields="content_vector")

        search_kwargs = {
            "search_text": None,  # pure vector search — no keyword/hybrid search component
            "vector_queries": [vector_query],
            "top": top_k,
            "select": [
                "id", "content", "source_filename", "page_number", "section_title",
                "content_type", "image_path", "document_type", "data_source", "allowed_roles",
            ],
        }
        if where:
            search_kwargs["filter"] = where
        if config.ENABLE_SEMANTIC_RANKING:
            search_kwargs["query_type"] = "semantic"
            search_kwargs["semantic_configuration_name"] = "default-semantic-config"

        results = self._client.search(**search_kwargs)

        output = []
        for result in results:
            # @search.reranker_score is only present when semantic ranking
            # ran; fall back to the plain vector @search.score otherwise,
            # so downstream code always has a usable ranking score.
            score = result.get("@search.reranker_score", result.get("@search.score", 0.0))
            output.append(
                RetrievedChunk(
                    chunk_id=result["id"],
                    text=result["content"],
                    score=score,
                    metadata={
                        "source_filename": result.get("source_filename"),
                        "page_number": result.get("page_number"),
                        "section_title": result.get("section_title"),
                        "content_type": result.get("content_type"),
                        "image_path": result.get("image_path"),
                        "document_type": result.get("document_type"),
                        "data_source": result.get("data_source"),
                        "allowed_roles": result.get("allowed_roles"),
                    },
                )
            )
        return output

    def count(self) -> int:
        return self._client.get_document_count()


# ---------------------------------------------------------------------------
# Singleton accessor — same reasoning as the local-first version: opening a
# SearchClient on every single query adds needless overhead under real
# traffic, so one instance is cached per process.
# ---------------------------------------------------------------------------
_vector_store_singleton: "VectorStore | None" = None


def get_vector_store() -> "VectorStore":
    global _vector_store_singleton
    if _vector_store_singleton is None:
        _vector_store_singleton = VectorStore()
    return _vector_store_singleton
