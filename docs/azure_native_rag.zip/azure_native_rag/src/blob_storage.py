"""
blob_storage.py
----------------
Thin wrapper around the Azure Blob Storage SDK — the only module that
talks to Blob Storage, so if you ever need to change how documents arrive
(e.g. SharePoint instead), this is the only file that changes.

Two ways to authenticate, chosen automatically:
  - AZURE_STORAGE_CONNECTION_STRING set -> uses that directly (simplest for
    local dev, works everywhere without any Azure login).
  - Not set, but a storage account name can be inferred -> falls back to
    DefaultAzureCredential (Managed Identity in Azure, `az login` locally).

For a first deployment, the connection-string path is the one to get
working first; switching the Container App to Managed Identity later is a
config change (removing the connection string, granting the "Storage Blob
Data Contributor" role to the app's identity), not a code change — see
README "Step 9".
"""

import os

from azure.storage.blob import BlobServiceClient

import config
from src.logging_setup import get_logger

logger = get_logger()


def _get_container_client():
    if not config.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError(
            "AZURE_STORAGE_CONNECTION_STRING is not set. "
            "Copy .env.example to .env and fill in your Azure Storage connection string, "
            "or set KEY_VAULT_URL and store it there instead."
        )

    blob_service_client = BlobServiceClient.from_connection_string(config.AZURE_STORAGE_CONNECTION_STRING)
    container_client = blob_service_client.get_container_client(config.AZURE_STORAGE_CONTAINER)

    if not container_client.exists():
        container_client.create_container()

    return container_client


def upload_directory(local_dir: str) -> None:
    """Upload every file under `local_dir` (recursively) to the configured container."""
    container_client = _get_container_client()

    for root, _dirs, files in os.walk(local_dir):
        for filename in files:
            local_path = os.path.join(root, filename)
            relative_path = os.path.relpath(local_path, local_dir)
            blob_name = relative_path.replace(os.sep, "/")

            with open(local_path, "rb") as data:
                container_client.upload_blob(name=blob_name, data=data, overwrite=True)
            logger.info(f"Uploaded: {blob_name}")


def download_container(local_dir: str) -> None:
    """Download every blob in the configured container into `local_dir`."""
    container_client = _get_container_client()
    os.makedirs(local_dir, exist_ok=True)

    blob_list = list(container_client.list_blobs())
    if not blob_list:
        logger.warning(f"No blobs found in container '{config.AZURE_STORAGE_CONTAINER}'. Nothing to download.")
        return

    for blob in blob_list:
        local_path = os.path.join(local_dir, blob.name)
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        downloader = container_client.download_blob(blob.name)
        with open(local_path, "wb") as f:
            f.write(downloader.readall())
        logger.info(f"Downloaded: {blob.name}")
