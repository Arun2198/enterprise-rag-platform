"""
dwg_converter.py
-----------------
Converts .dwg CAD drawings to .pdf, as a prerequisite step before they can
enter the rest of the pipeline. This is necessary because DWG is a
proprietary CAD geometry format — no Azure service (Document Intelligence
included) can open it directly. See the design discussion: DWG content
only becomes usable once it's a normal page image, at which point it
flows through the exact same visual-content track as any embedded diagram.

This module shells out to **ODA File Converter**, a free, standalone tool
from the Open Design Alliance (NOT a Python package — it must be installed
separately on the machine/container running ingestion; see README "DWG
conversion setup"). This is a deliberate, honest limitation: there is no
pure-Python or Azure-native way to read DWG geometry, so an external tool
is unavoidable here.

If the converter isn't installed, DWG files are skipped with a clear
warning rather than crashing the whole ingestion run — the rest of your
corpus (the other 80-90%) should still ingest successfully even if DWG
support isn't set up yet.
"""

import os
import shutil
import subprocess

import config
from src.logging_setup import get_logger

logger = get_logger()


def is_converter_available() -> bool:
    """Check whether the ODA File Converter executable can be found, without actually running it."""
    return shutil.which(config.ODA_FILE_CONVERTER_PATH) is not None


def convert_dwg_to_pdf(dwg_path: str, output_dir: str) -> str | None:
    """
    Convert one .dwg file to .pdf using ODA File Converter, returning the
    output PDF's path, or None if conversion wasn't possible (converter
    missing, or the conversion itself failed).

    ODA File Converter's CLI operates on whole FOLDERS, not single files
    (that's how the tool is designed), so this function copies the single
    input file into a temporary per-file input folder and points the
    converter at that — keeps the calling code simple (one file in, one
    PDF out) without needing callers to know about the tool's folder-based
    interface.
    """
    if not is_converter_available():
        logger.warning(
            f"ODA File Converter not found (looked for '{config.ODA_FILE_CONVERTER_PATH}' on PATH). "
            f"Skipping DWG conversion for {os.path.basename(dwg_path)} — see README 'DWG conversion setup'."
        )
        return None

    filename = os.path.splitext(os.path.basename(dwg_path))[0]
    temp_input_dir = os.path.join(output_dir, f"_dwg_input_{filename}")
    os.makedirs(temp_input_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    temp_dwg_path = os.path.join(temp_input_dir, os.path.basename(dwg_path))
    shutil.copy(dwg_path, temp_dwg_path)

    # ODA File Converter CLI signature:
    #   ODAFileConverter <in_folder> <out_folder> <out_version> <out_type> <recurse:0|1> <audit:0|1> [filter]
    # "ACAD2018" / "PDF" produces a PDF per input drawing; recurse=0 since
    # we've isolated exactly one file in temp_input_dir; audit=1 repairs
    # minor file corruption automatically rather than failing on it.
    command = [
        config.ODA_FILE_CONVERTER_PATH,
        temp_input_dir,
        output_dir,
        "ACAD2018",
        "PDF",
        "0",
        "1",
    ]

    try:
        subprocess.run(command, check=True, capture_output=True, timeout=120)
    except subprocess.CalledProcessError as exc:
        logger.error(f"ODA File Converter failed on {filename}: {exc.stderr}")
        return None
    except subprocess.TimeoutExpired:
        logger.error(f"ODA File Converter timed out converting {filename} (drawing may be very large/complex).")
        return None
    finally:
        shutil.rmtree(temp_input_dir, ignore_errors=True)

    expected_output = os.path.join(output_dir, f"{filename}.pdf")
    if os.path.exists(expected_output):
        logger.info(f"Converted {filename}.dwg -> {filename}.pdf")
        return expected_output

    logger.error(f"ODA File Converter ran but no output PDF was found for {filename}.")
    return None
