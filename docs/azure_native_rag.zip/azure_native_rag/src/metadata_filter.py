"""
metadata_filter.py
-------------------
Builds Azure AI Search OData `filter` strings for the retrieval layer:
RBAC/ACL (only return chunks the querying user's role is allowed to see),
document type, and data source filtering.

Unlike the ChromaDB version of this project, `allowed_roles` is stored as
a genuine list field in Azure AI Search (Collection(Edm.String)), so this
module filters it directly with OData's `any()` collection syntax instead
of needing per-role boolean flags. Simpler mapping, same capability.
"""

import config


def _escape(value: str) -> str:
    """
    OData string literals are single-quoted; a literal single-quote inside
    a value must be escaped as two single-quotes, or a role/filter value
    containing one would break the filter syntax (or, worse, let user
    input alter the filter's logic — the OData equivalent of a SQL
    injection risk). Always route values through this before interpolating
    them into a filter string.
    """
    return value.replace("'", "''")


def build_where_clause(
    user_roles: list[str] | None = None,
    document_type: str | None = None,
    data_source: str | None = None,
) -> str | None:
    """
    Build an OData filter string combining ACL, document type, and data
    source filters. Returns None if no filtering applies (Azure AI Search
    treats a missing `filter` as "match everything").

    Example output combining all three:
        "(allowed_roles/any(r: r eq 'admin') or allowed_roles/any(r: r eq 'employee')) "
        "and document_type eq 'financial' and data_source eq 'finance_team_share'"
    """
    clauses = []

    if config.ENABLE_ACL_FILTERING and user_roles:
        role_clauses = [
            f"allowed_roles/any(r: r eq '{_escape(role)}')" for role in user_roles if role in config.KNOWN_ROLES
        ]
        if role_clauses:
            clauses.append("(" + " or ".join(role_clauses) + ")" if len(role_clauses) > 1 else role_clauses[0])

    if document_type:
        clauses.append(f"document_type eq '{_escape(document_type)}'")

    if data_source:
        clauses.append(f"data_source eq '{_escape(data_source)}'")

    return " and ".join(clauses) if clauses else None
