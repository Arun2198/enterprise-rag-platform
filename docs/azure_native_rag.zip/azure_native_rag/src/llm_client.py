"""
llm_client.py
-------------
Sends a fully-built prompt to Azure OpenAI and returns the generated
answer. Azure OpenAI ONLY in this version — the local-first version also
supported Ollama as a free local fallback, but per the explicit "all
Azure-native" direction for this build, that branch was dropped rather
than kept as unused dead weight.

If you want a free local-dev iteration loop back (the earlier discussion
about "cheap generation locally, real embeddings against Azure" as a
middle-ground option), the natural place to reintroduce it is a
`_generate_with_ollama()` function here plus an `LLM_PROVIDER` config
check — the local-first version's llm_client.py is a ready-made reference
for exactly that branch if you decide you want it later.

`complete()` accepts a `model_override` so llm_router.py can direct a
specific request to either the fast or accurate Azure OpenAI deployment.
"""

from openai import AzureOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

import config
from src.logging_setup import get_logger

logger = get_logger()

_client: AzureOpenAI | None = None


def _get_client() -> AzureOpenAI:
    global _client
    if _client is None:
        _client = AzureOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
        )
    return _client


@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=30))
def complete(prompt: str, model_override: str | None = None) -> str:
    """
    Send `prompt` to Azure OpenAI and return the response text.
    `model_override` is the DEPLOYMENT name (not the underlying model
    name) — defaults to the fast tier if not specified.
    """
    client = _get_client()
    deployment = model_override or config.AZURE_OPENAI_CHAT_FAST_DEPLOYMENT

    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,  # low temperature keeps answers grounded/factual for RAG
    )
    return response.choices[0].message.content.strip()
