"""
guardrails.py
-------------
Input (blocked terms/PII) and output (grounding) checks — unchanged in
logic from the local-first version. Now ON by default (config.py), per
the decision that a publicly reachable endpoint shouldn't ship with safety
checks off, unlike a solo local POC where that was a reasonable default.
"""

import re
from dataclasses import dataclass

import config


@dataclass
class GuardrailResult:
    passed: bool
    reason: str | None = None


_PII_PATTERNS = {
    "possible_ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "possible_credit_card": re.compile(r"\b(?:\d[ -]*?){13,16}\b"),
}


def check_input(question: str) -> GuardrailResult:
    if not config.ENABLE_GUARDRAILS:
        return GuardrailResult(passed=True)

    lowered = question.lower()
    for term in config.GUARDRAIL_BLOCKED_TERMS:
        if term in lowered:
            return GuardrailResult(passed=False, reason=f"Question contains a blocked term: '{term}'")

    for pii_name, pattern in _PII_PATTERNS.items():
        if pattern.search(question):
            return GuardrailResult(
                passed=False,
                reason=f"Question appears to contain sensitive data ({pii_name}); please remove it and retry.",
            )

    return GuardrailResult(passed=True)


def _significant_words(text: str) -> set[str]:
    words = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return {w for w in words if len(w) >= 4}


def check_output(answer: str, context_chunks: list[str]) -> GuardrailResult:
    if not config.ENABLE_GUARDRAILS:
        return GuardrailResult(passed=True)

    answer_words = _significant_words(answer)
    if not answer_words:
        return GuardrailResult(passed=True)

    context_words = _significant_words(" ".join(context_chunks))
    grounding_ratio = len(answer_words & context_words) / len(answer_words)

    if grounding_ratio < config.GUARDRAIL_MIN_GROUNDING_RATIO:
        return GuardrailResult(
            passed=False,
            reason=(
                f"Low grounding ratio ({grounding_ratio:.2f}) between the answer and "
                "retrieved context — the answer may not be fully supported by the "
                "source documents. Treat it with extra caution."
            ),
        )
    return GuardrailResult(passed=True)
