"""
embedder.py
-----------
Turns text into vectors using Azure OpenAI's `text-embedding-3-small`
deployment — replaces the local-first version's free Sentence Transformers
model, per the decision to go fully Azure-native.

Two things this module handles that the local version didn't need to:
  1. BATCHING — the Azure OpenAI embeddings endpoint accepts a batch of
     inputs per call, but has request size limits. Chunks are sent in
     batches of `_BATCH_SIZE` rather than one giant request or one
     request per chunk (the former can hit request-size limits on a large
     corpus, the latter is needlessly slow and expensive in overhead).
  2. RETRY WITH BACKOFF — Azure OpenAI throttles (HTTP 429) under burst
     load. `tenacity` retries with exponential backoff automatically
     rather than letting a large ingestion run die on a transient
     rate-limit blip.
"""

from openai import AzureOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

import config
from src.logging_setup import get_logger

logger = get_logger()

_client: AzureOpenAI | None = None
_BATCH_SIZE = 100  # conservative batch size — comfortably under Azure OpenAI's per-request limits


def _get_client() -> AzureOpenAI:
    global _client
    if _client is None:
        _client = AzureOpenAI(
            azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
            api_key=config.AZURE_OPENAI_API_KEY,
            api_version=config.AZURE_OPENAI_API_VERSION,
        )
    return _client


@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=30))
def _embed_batch(texts: list[str]) -> list[list[float]]:
    client = _get_client()
    response = client.embeddings.create(model=config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT, input=texts)
    return [item.embedding for item in response.data]


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed a list of strings in batches, returning one vector per input string, same order."""
    all_embeddings: list[list[float]] = []
    for start in range(0, len(texts), _BATCH_SIZE):
        batch = texts[start : start + _BATCH_SIZE]
        all_embeddings.extend(_embed_batch(batch))
        logger.info(f"Embedded {min(start + _BATCH_SIZE, len(texts))}/{len(texts)} chunk(s).")
    return all_embeddings


def embed_single_text(text: str) -> list[float]:
    return embed_texts([text])[0]
